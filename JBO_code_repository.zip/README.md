# Osteosarcoma lactylation-mitophagy analysis

This repository contains the analysis code and derived summary tables for the manuscript:

**Cell-state-associated lactylation-mitophagy coupling and bridge-axis activation in osteosarcoma: a bulk, single-cell, and spatial transcriptomic study**

Authors: Shaomin Guo and Zeen Ren.

## Repository contents

- `code/`: analysis scripts for bulk, single-cell, spatial, and figure generation.
- `derived_tables/`: summary tables used in the manuscript and supplementary material.
- `metadata/`: data accessions and script-to-output mapping.
- `figures/`: final main figures.
- `requirements.txt`: Python package requirements.

## Data sources

Raw data are not redistributed here. All raw datasets are public.

| Dataset | Source | Use |
|---|---|---|
| TARGET-OS | GDC | Bulk discovery cohort |
| GSE21257 | GEO | Bulk external validation |
| GSE39055 | GEO | Bulk external validation |
| GSE33382 | GEO | Bulk external validation |
| GSE16091 | GEO | Bulk secondary context |
| GSE152048 | GEO | Single-cell samples BC2 and BC3 |
| GSE162454 | GEO | Single-cell sample OS_4 |
| GSE318840 | GEO | Single-cell treated and recurrent samples |
| GSE299025 | GEO | Visium spatial samples PatientA and PatientB |

Download and processing scripts are provided in `code/`. Raw files should be placed in the paths expected by those scripts.

## Main analysis steps

1. Download and harmonize bulk cohorts.
2. Compute lactylation (`L`) and mitophagy (`M`) scores.
3. Fit bulk association models and PyDESeq2 differential expression with `~ condition + sex + age`.
4. Process single-cell datasets and compute cell-type-specific L-M correlations.
5. Compute bridge-axis effect sizes and 20th, 25th, 30th and 33rd percentile sensitivity analyses.
6. Process Visium samples with Moran's I, spot-level Spearman correlations, and label-permutation neighborhood summaries.
7. Rebuild manuscript figures and supplementary tables.

## Key results

- Bulk lactylation scores were nominally associated in GSE21257 and GSE33382.
- Mitophagy and multiplicative LMC scores did not replicate in external cohorts.
- DESeq2 on TARGET-OS raw counts with sex and age identified 431 genes at FDR < 0.05 and 4,033 at nominal P < 0.05.
- L-M coupling was stronger in malignant/osteoblastic cells than in myeloid cells in datasets with adequate myeloid representation.
- HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 were directionally elevated in L-high and M-high malignant cells across five samples and four percentile thresholds.
- Spatial correlations were positive in both Visium samples; neighborhood enrichment is reported as descriptive because the label-permutation model does not preserve spatial autocorrelation.

## Reproducibility note

The analysis was run sequentially with a 16 GB memory limit. Single-cell samples were processed one at a time.

## License and release status

A license and public repository URL must be added before the repository is cited in the manuscript. Suggested options are MIT for code and CC-BY-4.0 for derived tables, subject to author approval.
