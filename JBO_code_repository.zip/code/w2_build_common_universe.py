from pathlib import Path
import pandas as pd
proc=Path('work/A1/02_data/processed')
sets={}
t=pd.read_csv(proc/'TARGET_OS_symbol_counts.tsv.gz',sep='\t',index_col=0,compression='gzip',usecols=[0])
sets['TARGET_OS']={str(x).upper() for x in t.index}
for gse in ['GSE21257','GSE33382','GSE39055','GSE16091']:
    m=pd.read_csv(proc/f'{gse}_gene_matrix_upper.tsv.gz',sep='\t',index_col=0,compression='gzip',usecols=[0])
    sets[gse]=set(m.index)
allgenes=sorted(set().union(*sets.values()))
df=pd.DataFrame({'gene':allgenes})
for k,v in sets.items(): df[k]=df.gene.isin(v).astype(int)
df['n_present']=df[list(sets)].sum(axis=1)
df.to_csv(proc/'A1_common_gene_universe.tsv',sep='\t',index=False)
print({k:len(v) for k,v in sets.items()})
print(df.n_present.value_counts().sort_index(ascending=False).to_dict())
print('primary 4 intersection',len(sets['TARGET_OS'] & sets['GSE21257'] & sets['GSE33382'] & sets['GSE39055']))
