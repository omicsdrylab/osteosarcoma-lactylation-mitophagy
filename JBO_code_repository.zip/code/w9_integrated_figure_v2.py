from pathlib import Path
import pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt, seaborn as sns
base=Path('work'); out=base/'A1_A2_integration'; out.mkdir(parents=True,exist_ok=True)
assoc=pd.read_csv(base/'A1/04_bulk/A1_score_outcome_associations.tsv',sep='\t'); lm=pd.read_csv(base/'A2/A2_week6b_LM_correlation.tsv',sep='\t'); axes=pd.read_csv(base/'A2/A2_week7_axis_by_LM_highlow.tsv',sep='\t'); sp=pd.read_csv(base/'A2/A2_week8_spatial_correlations.tsv',sep='\t')
fig,axs=plt.subplots(2,2,figsize=(18,14)); a=assoc[(assoc.dataset.isin(['GSE21257','GSE33382','GSE39055']))&(assoc.score.isin(['L_primary_z','M_primary_z','LMC_primary_z']))].copy(); y=0
for _,r in a.sort_values(['score','dataset']).iterrows(): axs[0,0].errorbar(r.OR_per_SD,y,xerr=[[max(0,r.OR_per_SD-r.CI_low)],[max(0,r.CI_high-r.OR_per_SD)]],fmt='o',capsize=2); y+=1
axs[0,0].axvline(1,color='black',ls='--'); axs[0,0].set_yticks(range(len(a))); axs[0,0].set_yticklabels([f'{r.dataset} {r.score}' for _,r in a.sort_values(['score','dataset']).iterrows()],fontsize=7); axs[0,0].set_title('A. Bulk external evaluation'); axs[0,0].set_xlabel('OR per SD')
lm2=lm[lm.cell_type.isin(['Malignant_Osteoblastic','Myeloid'])]; sns.barplot(data=lm2,x='dataset',y='spearman_L_M',hue='cell_type',ax=axs[0,1]); axs[0,1].axhline(0,color='black'); axs[0,1].tick_params(axis='x',rotation=35); axs[0,1].set_title('B. Cell-type-specific L-M coupling'); axs[0,1].set_ylabel('Spearman correlation')
m=axes[axes.anchor=='L_primary'].pivot(index='sample',columns='axis',values='cliff_delta'); sns.heatmap(m,cmap='RdBu_r',center=0,ax=axs[1,0]); axs[1,0].set_title('C. Bridge axes in L-high malignant cells')
pairs=[('L_primary','M_primary'),('L_primary','HK_PRKN'),('L_primary','HDAC6_SQSTM1'),('L_primary','SIRT1_ATG'),('M_primary','HK_PRKN'),('M_primary','HDAC6_SQSTM1'),('M_primary','SIRT1_ATG')]; sp2=sp.set_index(['score1','score2']).loc[pairs].reset_index(); mat=sp2.pivot(index=['score1','score2'],columns='sample',values='spearman'); sns.heatmap(mat,cmap='RdBu_r',center=0,ax=axs[1,1]); axs[1,1].set_title('D. Spatial L/M-bridge-axis correlations')
fig.suptitle('Bulk-negative, single-cell-positive, spatially structured lactylation–mitophagy coupling',fontsize=15); fig.tight_layout(rect=[0,0,1,0.96]); fig.savefig(out/'A1_A2_integrated_model_v2.png',dpi=300); fig.savefig(out/'A1_A2_integrated_model_v2.pdf'); plt.close(fig); print('v2 figure written')
