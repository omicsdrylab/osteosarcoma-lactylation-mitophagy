from pathlib import Path
import numpy as np
import pandas as pd
from pydeseq2.dds import DeseqDataSet
from pydeseq2.ds import DeseqStats

root = Path(r'C:\Users\常昆\Documents\Codex\2026-10-02\w')
proc = root / 'work' / 'A1' / '02_data' / 'processed'
out = root / 'work' / 'A1' / '04_bulk_deseq2'
out.mkdir(parents=True, exist_ok=True)

counts = pd.read_csv(proc / 'TARGET_OS_symbol_counts.tsv.gz', sep='\t', index_col=0, compression='gzip')
meta = pd.read_csv(proc / 'A1_harmonized_metadata.tsv', sep='\t')
meta = meta.loc[meta['dataset'] == 'TARGET_OS'].set_index('sample_id')
common = counts.columns.intersection(meta.index)
counts = counts.loc[:, common]
meta = meta.loc[common].copy()
counts = counts.apply(pd.to_numeric, errors='coerce').fillna(0).clip(lower=0).round().astype(int)
keep = (counts >= 10).sum(axis=1) >= 10
counts = counts.loc[keep]
meta['condition'] = meta['primary_event'].map({1.0: 'event', 0.0: 'no_event'})
meta['sex'] = meta['sex'].astype(str).str.lower().map({'male': 'male', 'female': 'female'})
meta['condition'] = pd.Categorical(meta['condition'], categories=['no_event', 'event'])
meta['sex'] = pd.Categorical(meta['sex'], categories=['female', 'male'])
age = pd.to_numeric(meta['age_value'], errors='coerce')
meta['age_scaled'] = (age - age.mean()) / age.std(ddof=0)
meta = meta[['condition', 'sex', 'age_scaled']]
print('counts shape', counts.shape, 'age range', age.min(), age.max(), flush=True)

dds = DeseqDataSet(counts=counts.T, metadata=meta, design='~ condition + sex + age_scaled', refit_cooks=True, n_cpus=1, low_memory=True, quiet=False)
dds.deseq2()
stat = DeseqStats(dds, contrast=['condition', 'event', 'no_event'], alpha=0.05, independent_filter=True, n_cpus=1, quiet=False)
stat.summary()
res = stat.results_df.copy(); res.insert(0, 'gene', res.index)
res.to_csv(out / 'TARGET_OS_DESeq2_primary_event_age.tsv', sep='\t', index=False)
pd.DataFrame({'metric':['samples','genes_tested','fdr_lt_0.05','nominal_p_lt_0.05','genes_with_padj'],'value':[len(common),res.shape[0],int((res['padj']<0.05).sum()),int((res['pvalue']<0.05).sum()),int(res['padj'].notna().sum())]}).to_csv(out/'TARGET_OS_DESeq2_age_summary.tsv',sep='\t',index=False)
print('FDR<0.05', int((res['padj']<0.05).sum()), 'nominal p<0.05', int((res['pvalue']<0.05).sum()), flush=True)
