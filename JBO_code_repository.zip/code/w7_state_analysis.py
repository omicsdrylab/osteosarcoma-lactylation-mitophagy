from pathlib import Path
import pandas as pd, numpy as np, scanpy as sc, gc
from sklearn.cluster import KMeans
from scipy.stats import spearmanr
base=Path('work/A2'); gene=Path('work/A1/01_genesets')
lac=pd.read_csv(gene/'lactylation_genes_v1.tsv',sep='\t'); mit=pd.read_csv(gene/'mitophagy_genes_v1.tsv',sep='\t')
state_sets={'Hypoxia':['HIF1A','VEGFA','SLC2A1','LDHA','PGK1','ENO1','HK2','PDK1','BNIP3','NDRG1','ADM','CA9','EGLN3','ANGPTL4'],'Proliferation':['MKI67','PCNA','TOP2A','CCNB1','CCNB2','CDK1','AURKA','AURKB','BIRC5','E2F1'],'EMT':['VIM','FN1','SNAI1','SNAI2','TWIST1','ZEB1','ZEB2','MMP2','MMP9'],'Osteoblastic':['COL1A1','COL1A2','SPARC','ALPL','RUNX2','SP7','IBSP','SPP1','SATB2'],'M1_Inflammatory':['TNF','IL1B','CXCL8','CXCL10','NFKB1','RELA','STAT1','CD80','CD86'],'M2_TAM':['CD163','MRC1','MSR1','IL10','TGFB1','ARG1','VEGFA','CCL22'],'AntigenPresentation':['HLA-DRA','HLA-DRB1','CD74','TAP1','B2M','PSMB9'],'Stemness':['SOX2','NANOG','POU5F1','MYC','KLF4','PROM1','ALDH1A1','CD44','THY1','BMI1'],'L_primary':lac.query('include_primary==1').gene.tolist(),'M_primary':mit.query('include_primary_GO==1').gene.tolist(),'HK_PRKN':['HK1','HK2','PKM','PRKN'],'HDAC6_SQSTM1':['HDAC6','SQSTM1'],'SIRT1_ATG':['SIRT1','ATG5','ATG7','MAP1LC3B','GABARAPL1'],'HIF1A_BNIP3':['HIF1A','BNIP3']}
samples={'GSE152048_BC2':(base/'incoming/GSE152048/BC2',base/'GSE152048_BC2_cell_scores.tsv.gz'),'GSE152048_BC3':(base/'incoming/GSE152048/BC3',base/'GSE152048_BC3_cell_scores.tsv.gz'),'GSE162454_OS4':(base/'incoming/GSE162454/OS_4',base/'GSE162454_OS4_cell_scores.tsv.gz'),'GSE318840_Treated1':(base/'incoming/GSE318840/Treated1',base/'GSE318840_Treated1_cell_scores.tsv.gz'),'GSE318840_Recurrent1':(base/'incoming/GSE318840/Recurrent1',base/'GSE318840_Recurrent1_cell_scores.tsv.gz')}
all_cells=[]; summaries=[]; corrs=[]; pb=[]
for sample,(path,metafile) in samples.items():
 print('processing',sample,flush=True); meta0=pd.read_csv(metafile,sep='\t',index_col=0); a=sc.read_10x_mtx(path,var_names='gene_symbols',make_unique=True); a.var_names=a.var_names.astype(str).str.upper(); a.var_names_make_unique(); sc.pp.filter_cells(a,min_genes=200); sc.pp.filter_genes(a,min_cells=3); common=a.obs_names.intersection(meta0.index); print('cells',a.n_obs,'matched',len(common),flush=True); a=a[common].copy(); meta0=meta0.loc[common]; sc.pp.normalize_total(a,target_sum=1e4); sc.pp.log1p(a)
 for name,genes in state_sets.items():
  gs=[g for g in genes if g in a.var_names]
  if not gs: a.obs[name]=np.nan; continue
  X=np.asarray(a[:,gs].X.todense()); mu=X.mean(0); sd=X.std(0); sd[sd==0]=1; a.obs[name]=((X-mu)/sd).mean(1)
 a.obs['sample']=sample; a.obs['cell_type']=meta0['cell_type'].values
 for ct in ['Malignant_Osteoblastic','Myeloid']:
  idx=a.obs['cell_type']==ct
  if idx.sum()<50: continue
  sub=a[idx].copy()
  genes=sorted(set(sum([v for v in state_sets.values()],[])) & set(sub.var_names))
  for g in genes: pb.append({'sample':sample,'cell_type':ct,'gene':g,'mean_logexpr':float(np.asarray(sub[:,g].X.mean()))})
  sc.pp.highly_variable_genes(sub,n_top_genes=1500,subset=True); sc.pp.scale(sub,max_value=10); sc.tl.pca(sub,n_comps=min(30,sub.n_obs-1,sub.n_vars-1),svd_solver='arpack'); k=min(4,max(2,sub.n_obs//150)); km=KMeans(n_clusters=k,random_state=20261005,n_init=10).fit(sub.obsm['X_pca']); sub.obs['subcluster']=km.labels_.astype(str)
  cols=list(state_sets.keys()); s=sub.obs.groupby('subcluster',observed=True)[cols].mean(); s['n_cells']=sub.obs.groupby('subcluster',observed=True).size(); s['sample']=sample; s['cell_type']=ct; summaries.append(s.reset_index())
  for subc,g in sub.obs.groupby('subcluster'):
   if len(g)>=30: rho,p=spearmanr(g.L_primary,g.M_primary); corrs.append({'sample':sample,'cell_type':ct,'subcluster':subc,'n_cells':len(g),'stratifier':'all','stratum':'all','spearman_L_M':rho,'p_value':p})
  for strat in ['Hypoxia','Proliferation']:
   med=sub.obs[strat].median(); g=sub.obs
   for label,mask in [('high',g[strat]>med),('low',g[strat]<=med)]:
    gg=g[mask]
    if len(gg)>=30:
     rho,p=spearmanr(gg.L_primary,gg.M_primary); corrs.append({'sample':sample,'cell_type':ct,'subcluster':'all','n_cells':len(gg),'stratifier':strat,'stratum':label,'spearman_L_M':rho,'p_value':p})
  out=sub.obs[['sample','cell_type','subcluster']+cols].copy(); out.index.name='cell_id'; all_cells.append(out)
 del a,sub; gc.collect()
pd.concat(all_cells,ignore_index=True).to_csv(base/'A2_week7_cell_states.tsv.gz',sep='\t',index=False,compression='gzip'); pd.concat(summaries,ignore_index=True).to_csv(base/'A2_week7_subcluster_summary.tsv',sep='\t',index=False); pd.DataFrame(corrs).to_csv(base/'A2_week7_LM_state_correlations.tsv',sep='\t',index=False); pd.DataFrame(pb).to_csv(base/'A2_week7_pseudobulk_targets.tsv',sep='\t',index=False); print('done')


