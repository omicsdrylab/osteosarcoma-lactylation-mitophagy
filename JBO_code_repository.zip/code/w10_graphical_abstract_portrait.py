from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

out = Path(r'C:\Users\常昆\Documents\Codex\2026-10-02\w\outputs\JBO_submission')
out.mkdir(parents=True, exist_ok=True)
fig = plt.figure(figsize=(5.31, 13.28), dpi=100)
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')

def box(x, y, w, h, title, body, color):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.012', facecolor=color, edgecolor='#23395d', linewidth=1.5))
    ax.text(x + w/2, y + h*0.67, title, ha='center', va='center', fontsize=10.5, weight='bold', color='#10233f')
    ax.text(x + w/2, y + h*0.32, body, ha='center', va='center', fontsize=8.3, color='#10233f')

ax.text(0.5, 0.965, 'Cell-state-specific lactylation-mitophagy coupling in osteosarcoma', ha='center', va='center', fontsize=12.5, weight='bold', color='#10233f', wrap=True)
box(0.08, 0.785, 0.84, 0.105, 'Bulk cohorts', 'L score nominally associated; M and LMC not replicated', '#e9f1fb')
box(0.08, 0.625, 0.84, 0.105, 'Single-cell samples', 'Malignant/osteoblastic L-M coupling > myeloid cells', '#e8f6f1')
box(0.08, 0.465, 0.84, 0.105, 'Spatial Visium', 'L/M autocorrelation and bridge-axis co-localization', '#fff1df')
box(0.08, 0.305, 0.84, 0.105, 'Representative bridge axes', 'HK-PRKN | SIRT1-ATG | HDAC6-SQSTM1', '#f7e8ef')
for y0, y1 in [(0.785,0.735),(0.625,0.575),(0.465,0.415),(0.305,0.255)]:
    ax.add_patch(FancyArrowPatch((0.50, y0), (0.50, y1), arrowstyle='-|>', mutation_scale=16, linewidth=2, color='#23395d'))
box(0.08, 0.075, 0.84, 0.135, 'L/M-high malignant state', 'HK-PRKN | SIRT1-ATG | HDAC6-SQSTM1\nAdjacent M2/TAM immunosuppressive niche', '#dfe9fb')
ax.add_patch(FancyArrowPatch((0.50, 0.305), (0.50, 0.21), arrowstyle='-|>', mutation_scale=16, linewidth=2, color='#23395d'))
fig.savefig(out / 'JBO_graphical_abstract_portrait.png', dpi=100)
fig.savefig(out / 'JBO_graphical_abstract_portrait.pdf')
fig.savefig(out / 'JBO_graphical_abstract_portrait.tiff', dpi=300)
plt.close(fig)
print('portrait graphical abstract written')
