from pathlib import Path
import pandas as pd, numpy as np, statsmodels.api as sm
out=Path('work/A1/04_bulk'); proc=Path('work/A1/02_data/processed')
s=pd.read_csv(out/'A1_rankssGSEA_scores_z.tsv',sep='\t'); meta=pd.read_csv(proc/'A1_harmonized_metadata.tsv',sep='\t')
cohort_events={'TARGET_OS':'primary_event','GSE21257':'metastasis_event','GSE39055':'recurrence_event','GSE33382':'metastasis_event'}; rows=[]
for ds,ev in cohort_events.items():
    m=meta[(meta.dataset==ds)&meta[ev].notna()][['sample_id',ev]]; d=s[s.dataset==ds].merge(m,on='sample_id'); d=d[d[ev].notna()].copy(); d['L_high']=(d.L_primary_z>d.L_primary_z.median()).astype(int); d['M_high']=(d.M_primary_z>d.M_primary_z.median()).astype(int); d['LxM']=d.L_high*d.M_high; d['group']=d.apply(lambda r: ('Lhigh_Mhigh' if r.L_high and r.M_high else 'Lhigh_Mlow' if r.L_high else 'Llow_Mhigh' if r.M_high else 'Llow_Mlow'),axis=1)
    X=sm.add_constant(d[['L_high','M_high','LxM']].astype(float)); model=sm.GLM(d[ev].astype(float),X,family=sm.families.Binomial()).fit(); ci=model.conf_int().loc['LxM']; rows.append({'dataset':ds,'n':len(d),'interaction_beta':model.params['LxM'],'interaction_OR':np.exp(model.params['LxM']),'CI_low':np.exp(ci[0]),'CI_high':np.exp(ci[1]),'p_interaction':model.pvalues['LxM']})
res=pd.DataFrame(rows); res.to_csv(out/'A1_LMC_interaction_tests.tsv',sep='\t',index=False); print(res.to_string(index=False))
