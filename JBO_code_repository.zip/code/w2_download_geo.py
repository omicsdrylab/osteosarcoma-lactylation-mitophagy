from pathlib import Path
import requests
base=Path('work/A1/02_data/raw/GEO'); base.mkdir(parents=True,exist_ok=True)
gses=['GSE21257','GSE39055','GSE33382','GSE16091','GSE42352','GSE14359']
log=[]
for g in gses:
    prefix=g[:-3]+'nnn'
    u=f'https://ftp.ncbi.nlm.nih.gov/geo/series/{prefix}/{g}/matrix/{g}_series_matrix.txt.gz'
    p=base/f'{g}_series_matrix.txt.gz'
    try:
        with requests.get(u,stream=True,timeout=120) as r:
            r.raise_for_status()
            with p.open('wb') as f:
                for chunk in r.iter_content(1024*1024): f.write(chunk)
        log.append({'gse':g,'url':u,'status':'downloaded','size':p.stat().st_size})
        print(g,p.stat().st_size)
    except Exception as e:
        log.append({'gse':g,'url':u,'status':'failed','error':repr(e)})
        print('FAILED',g,repr(e))
import pandas as pd
pd.DataFrame(log).to_csv(base/'GEO_download_log.csv',index=False)
