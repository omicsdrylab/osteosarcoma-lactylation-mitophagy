from pathlib import Path
import pandas as pd, numpy as np
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
proc=Path('work/A1/02_data/processed'); out=Path('work/A1/04_bulk')
s=pd.read_csv(out/'A1_rankssGSEA_scores_z.tsv',sep='\t'); meta=pd.read_csv(proc/'A1_harmonized_metadata.tsv',sep='\t')
score_cols=['L_primary_z','L_core_z','L_context_z','M_primary_z','M_extended_z','LMC_primary_z','LMC_extended_z','Hypoxia_z','Glycolysis_z','OXPHOS_z','ROS_z','EMT_z','Stemness_z','Inflammatory_IL6_z','Cell_cycle_z']
cohort_events={'TARGET_OS':'primary_event','GSE21257':'metastasis_event','GSE39055':'recurrence_event','GSE33382':'metastasis_event','GSE16091':'death_event'}
results=[]
for ds,event_col in cohort_events.items():
    m=meta[(meta.dataset==ds)&meta[event_col].notna()][['sample_id',event_col]]; d=s[s.dataset==ds].merge(m,on='sample_id',how='inner')
    if d.empty or d[event_col].nunique()<2: continue
    for sc in score_cols:
        x=d[[sc]].apply(pd.to_numeric,errors='coerce'); ok=x[sc].notna(); xx=x.loc[ok]; y=d.loc[ok,event_col].astype(float).reset_index(drop=True); xx=xx.reset_index(drop=True)
        if len(y)<15: continue
        X=sm.add_constant(xx.astype(float)); model=sm.GLM(y,X,family=sm.families.Binomial()).fit()
        beta=model.params[sc]; ci=model.conf_int().loc[sc]; results.append({'dataset':ds,'event':event_col,'score':sc,'n':len(y),'events':int(y.sum()),'OR_per_SD':float(np.exp(beta)),'CI_low':float(np.exp(ci[0])),'CI_high':float(np.exp(ci[1])),'p_value':float(model.pvalues[sc]),'direction':'positive' if beta>0 else 'negative'})
r=pd.DataFrame(results); r['FDR_within_cohort']=np.nan
for ds,g in r.groupby('dataset'): r.loc[g.index,'FDR_within_cohort']=multipletests(g.p_value,method='fdr_bh')[1]
r.to_csv(out/'A1_score_outcome_associations.tsv',sep='\t',index=False)
primary=r[(r.dataset.isin(['GSE21257','GSE39055','GSE33382']))&(r.score.isin(['L_primary_z','M_primary_z','LMC_primary_z']))].copy()
lines=['# A1 Week 3 Gate 1 Report','','Primary endpoint: metastasis or relapse/progression event.','','| Dataset | Score | n | Events | OR per SD | 95% CI | p | FDR | Direction |','|---|---|---:|---:|---:|---|---:|---:|---|']
for _,x in primary.sort_values(['score','dataset']).iterrows(): lines.append(f"| {x.dataset} | {x.score} | {int(x.n)} | {int(x.events)} | {x.OR_per_SD:.3f} | {x.CI_low:.3f}-{x.CI_high:.3f} | {x.p_value:.4g} | {x.FDR_within_cohort:.4g} | {x.direction} |")
lines += ['','## Gate 1 decision','']; passed=[]
for sc in ['L_primary_z','M_primary_z','LMC_primary_z']:
    g=primary[primary.score==sc]; sig=g[g.p_value<0.05]; dirs=sig.direction.value_counts()
    if len(sig)>=2 and dirs.max()>=2: passed.append(sc)
lines.append('**PASS** for: '+', '.join(passed)+'. At least two independent external cohorts show a nominally significant association in the same direction.' if passed else '**NOT PASS**: fewer than two external cohorts show a nominally significant association in the same direction. Continue subtype analysis but do not claim clinical replication yet.')
Path(out/'A1_Gate1_report.md').write_text('\n'.join(lines),encoding='utf-8')
print(r.sort_values(['dataset','p_value']).head(40).to_string(index=False)); print('Gate passed',passed)
