from pathlib import Path
import requests, json, pandas as pd
BASE=Path('work/A1/02_data/raw/TARGET_OS'); BASE.mkdir(parents=True,exist_ok=True)
G='https://api.gdc.cancer.gov'
filter_files={'op':'and','content':[
 {'op':'in','content':{'field':'cases.project.project_id','value':['TARGET-OS']}},
 {'op':'in','content':{'field':'data_type','value':['Gene Expression Quantification']}},
 {'op':'in','content':{'field':'analysis.workflow_type','value':['STAR - Counts']}},
 {'op':'in','content':{'field':'access','value':['open']}}
]}
body={'filters':filter_files,'fields':'file_id,file_name,md5sum,file_size,state,data_type,analysis.workflow_type,cases.case_id,cases.submitter_id,cases.samples.sample_id,cases.samples.submitter_id,cases.samples.sample_type,cases.samples.tissue_type','format':'JSON','size':2000}
r=requests.post(G+'/files',json=body,timeout=90); r.raise_for_status(); j=r.json()
print('file hits',j['data']['pagination']['total'])
(BASE/'gdc_files.json').write_text(json.dumps(j,ensure_ascii=False,indent=2),encoding='utf-8')
rows=[]
for h in j['data']['hits']:
    cases=h.get('cases',[])
    for c in cases:
        samples=c.get('samples',[])
        if not samples:
            rows.append({'file_id':h['file_id'],'file_name':h['file_name'],'md5sum':h.get('md5sum'),'file_size':h.get('file_size'),'case_id':c.get('case_id'),'case_submitter_id':c.get('submitter_id'),'sample_id':'','sample_submitter_id':'','sample_type':'','tissue_type':''})
        for s in samples:
            rows.append({'file_id':h['file_id'],'file_name':h['file_name'],'md5sum':h.get('md5sum'),'file_size':h.get('file_size'),'case_id':c.get('case_id'),'case_submitter_id':c.get('submitter_id'),'sample_id':s.get('sample_id'),'sample_submitter_id':s.get('submitter_id'),'sample_type':s.get('sample_type'),'tissue_type':s.get('tissue_type')})
df=pd.DataFrame(rows); df.to_csv(BASE/'TARGET_OS_expression_files.csv',index=False)
print(df.head(10).to_string(index=False))
print('unique files',df.file_id.nunique(),'unique cases',df.case_id.nunique(),'unique samples',df.sample_submitter_id.nunique())
filters={'op':'in','content':{'field':'project.project_id','value':['TARGET-OS']}}
params={'filters':json.dumps(filters),'expand':'diagnoses,demographic,follow_ups,exposures','format':'JSON','size':2000,'fields':'case_id,submitter_id,diagnoses,demographic,follow_ups,exposures'}
r=requests.get(G+'/cases',params=params,timeout=120); r.raise_for_status(); cj=r.json()
(BASE/'gdc_clinical_raw.json').write_text(json.dumps(cj,ensure_ascii=False,indent=2),encoding='utf-8')
print('clinical hits',cj['data']['pagination']['total'])
