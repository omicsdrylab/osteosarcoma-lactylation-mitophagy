from pathlib import Path
import pandas as pd, numpy as np
from scipy.stats import mannwhitneyu
base=Path('work/A2'); d=pd.read_csv(base/'A2_week7_cell_states.tsv.gz',sep='\t'); axes=['HK_PRKN','HDAC6_SQSTM1','SIRT1_ATG','HIF1A_BNIP3']; rows=[]
for sample,g in d[d.cell_type=='Malignant_Osteoblastic'].groupby('sample'):
    for anchor in ['L_primary','M_primary']:
        q1,q3=g[anchor].quantile([.25,.75]); hi=g[g[anchor]>=q3]; lo=g[g[anchor]<=q1]
        for ax in axes:
            u,p=mannwhitneyu(hi[ax].dropna(),lo[ax].dropna(),alternative='two-sided'); delta=2*u/(len(hi)*len(lo))-1; rows.append({'sample':sample,'anchor':anchor,'axis':ax,'n_high':len(hi),'n_low':len(lo),'mean_high':hi[ax].mean(),'mean_low':lo[ax].mean(),'difference':hi[ax].mean()-lo[ax].mean(),'cliff_delta':delta,'p_value':p,'direction':'higher_in_high' if delta>0 else 'higher_in_low'})
r=pd.DataFrame(rows); r.to_csv(base/'A2_week7_axis_by_LM_highlow.tsv',sep='\t',index=False); print(r.sort_values(['anchor','axis','sample']).to_string(index=False))
