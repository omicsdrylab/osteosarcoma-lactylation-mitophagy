from pathlib import Path
import requests,time
from concurrent.futures import ThreadPoolExecutor,as_completed
base='https://ftp.ncbi.nlm.nih.gov/geo/samples/GSM9030nnn/'
files={'A_matrix':'GSM9030938/suppl/GSM9030938_PatientA_matrix.mtx.gz','A_pos':'GSM9030938/suppl/GSM9030938_PatientA_tissue_positions_list.csv.gz','B_barcodes':'GSM9030939/suppl/GSM9030939_PatientB_barcodes.tsv.gz','B_features':'GSM9030939/suppl/GSM9030939_PatientB_features.tsv.gz','B_matrix':'GSM9030939/suppl/GSM9030939_PatientB_matrix.mtx.gz','B_pos':'GSM9030939/suppl/GSM9030939_PatientB_tissue_positions_list.csv.gz'}
outmap={'A_matrix':Path('work/A2/incoming/GSE299025/PatientA/matrix.mtx.gz'),'A_pos':Path('work/A2/incoming/GSE299025/PatientA/tissue_positions_list.csv.gz'),'B_barcodes':Path('work/A2/incoming/GSE299025/PatientB/barcodes.tsv.gz'),'B_features':Path('work/A2/incoming/GSE299025/PatientB/features.tsv.gz'),'B_matrix':Path('work/A2/incoming/GSE299025/PatientB/matrix.mtx.gz'),'B_pos':Path('work/A2/incoming/GSE299025/PatientB/tissue_positions_list.csv.gz')}
for key,rel in files.items():
    p=outmap[key]; p.parent.mkdir(parents=True,exist_ok=True); url=base+rel
    for attempt in range(5):
        try:
            h=requests.head(url,timeout=60); h.raise_for_status(); total=int(h.headers['Content-Length']); break
        except Exception as e:
            print('head retry',key,attempt+1,repr(e),flush=True); time.sleep(10)
    else: raise SystemExit(1)
    if p.exists() and p.stat().st_size==total: print('skip',key,flush=True); continue
    chunk=2*1024*1024; ranges=[(s,min(s+chunk-1,total-1)) for s in range(0,total,chunk)]; start=time.time()
    def get(i,s,e):
        for a in range(8):
            try:
                r=requests.get(url,headers={'Range':f'bytes={s}-{e}'},timeout=180); r.raise_for_status(); return i,r.content
            except Exception:
                if a==7: raise
                time.sleep(5*(a+1))
    parts={}
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs=[ex.submit(get,i,s,e) for i,(s,e) in enumerate(ranges)]
        for f in as_completed(futs): i,d=f.result(); parts[i]=d
    tmp=p.with_suffix(p.suffix+'.part')
    with tmp.open('wb') as fh:
        for i in range(len(ranges)): fh.write(parts[i])
    tmp.replace(p); print(key,total,'seconds',round(time.time()-start,1),flush=True)
print('ALL DONE',flush=True)
