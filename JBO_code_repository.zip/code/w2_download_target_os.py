from pathlib import Path
import pandas as pd, requests, hashlib, time
from concurrent.futures import ThreadPoolExecutor, as_completed
base=Path('work/A1/02_data/raw/TARGET_OS'); out=base/'files'; out.mkdir(parents=True,exist_ok=True)
df=pd.read_csv(base/'TARGET_OS_expression_files.csv')
records=df.drop_duplicates('file_id').to_dict('records')
G='https://api.gdc.cancer.gov/data/'
def download(rec):
    fid=rec['file_id']; name=rec['file_name']; path=out/name
    if path.exists() and hashlib.md5(path.read_bytes()).hexdigest()==rec['md5sum']:
        return {'file_id':fid,'file_name':name,'status':'exists','size':path.stat().st_size,'md5_ok':True}
    url=G+fid
    for attempt in range(3):
        try:
            with requests.get(url,stream=True,timeout=180) as r:
                r.raise_for_status()
                tmp=path.with_suffix(path.suffix+'.part')
                h=hashlib.md5()
                with tmp.open('wb') as f:
                    for chunk in r.iter_content(1024*1024):
                        f.write(chunk); h.update(chunk)
                md5=h.hexdigest()
                if md5==rec['md5sum']:
                    tmp.replace(path)
                    return {'file_id':fid,'file_name':name,'status':'downloaded','size':path.stat().st_size,'md5_ok':True}
                tmp.unlink(missing_ok=True)
                raise RuntimeError(f'md5 mismatch {md5} vs {rec["md5sum"]}')
        except Exception as e:
            if attempt==2: return {'file_id':fid,'file_name':name,'status':'failed','size':0,'md5_ok':False,'error':repr(e)}
            time.sleep(2*(attempt+1))
with ThreadPoolExecutor(max_workers=6) as ex:
    futs=[ex.submit(download,r) for r in records]
    rows=[]
    for i,f in enumerate(as_completed(futs),1):
        row=f.result(); rows.append(row)
        if i%10==0 or row['status']!='downloaded': print(i,row['status'],row['file_name'],flush=True)
pd.DataFrame(rows).to_csv(base/'TARGET_OS_download_log.csv',index=False)
print('done files',len(rows),'ok',sum(r['md5_ok'] for r in rows),'failed',sum(r['status']=='failed' for r in rows))
