from pathlib import Path
import pandas as pd
raw=Path('work/A1/02_data/raw/GEO'); proc=Path('work/A1/02_data/processed'); pl=raw/'platforms'
plat_info={'GPL96':('ID','Gene Symbol'),'GPL10295':('ID','Symbol'),'GPL14951':('ID','Symbol')}
maps={}
for gpl,(idc,syc) in plat_info.items():
    p=pl/f'{gpl}_platform_full.txt'
    with p.open('r',encoding='utf-8',errors='replace') as f:
        lines=f.read().splitlines()
    start=next(i for i,l in enumerate(lines) if l.startswith('!platform_table_begin'))
    end=next(i for i,l in enumerate(lines) if l.startswith('!platform_table_end'))
    df=pd.read_csv(p,sep='\t',skiprows=start+1,nrows=end-start-1,dtype=str,low_memory=False)
    sym=df[syc].fillna('').astype(str).str.split('///').str[0].str.strip()
    m=pd.DataFrame({'probe':df[idc].astype(str).str.strip(),'gene':sym})
    m=m[(m.probe!='') & (m.gene!='') & (~m.gene.str.lower().isin(['nan','---']))].drop_duplicates('probe')
    m.to_csv(proc/f'{gpl}_probe_gene_map.tsv.gz',sep='\t',index=False,compression='gzip')
    maps[gpl]=dict(zip(m.probe,m.gene))
    print(gpl,'probes',df.shape[0],'mapped',len(m),'unique genes',m.gene.nunique())
platform_by_gse={'GSE21257':'GPL10295','GSE33382':'GPL10295','GSE42352':'GPL10295','GSE39055':'GPL14951','GSE16091':'GPL96','GSE14359':'GPL96'}
for gse,gpl in platform_by_gse.items():
    mat=pd.read_csv(proc/f'{gse}_expression_raw.tsv.gz',sep='\t',compression='gzip',low_memory=False)
    idcol=mat.columns[0]
    mat['gene']=mat[idcol].astype(str).map(maps[gpl])
    mat=mat[mat.gene.notna()].copy()
    sample_cols=[c for c in mat.columns if c.startswith('GSM')]
    mat[sample_cols]=mat[sample_cols].apply(pd.to_numeric,errors='coerce')
    mat['_mean']=mat[sample_cols].mean(axis=1,skipna=True)
    mat=mat.sort_values('_mean',ascending=False).drop_duplicates('gene').set_index('gene')[sample_cols]
    mat.index.name='gene'
    mat.to_csv(proc/f'{gse}_gene_matrix.tsv.gz',sep='\t',compression='gzip')
    qc=[]
    for s in sample_cols:
        vals=mat[s]
        qc.append({'gse':gse,'gsm':s,'n_genes':int(vals.notna().sum()),'missing_fraction':float(vals.isna().mean()),'min':float(vals.min(skipna=True)),'median':float(vals.median(skipna=True)),'max':float(vals.max(skipna=True)),'sd':float(vals.std(skipna=True))})
    pd.DataFrame(qc).to_csv(proc/f'{gse}_sample_qc.tsv',sep='\t',index=False)
    print(gse,'gene matrix',mat.shape,'sample qc',len(qc))
