from pathlib import Path
from PIL import Image
import pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt, seaborn as sns
out=Path('outputs/manuscript_v0/figures'); out.mkdir(parents=True,exist_ok=True)
def stitch(paths,outpath,width=2400,bg='white'):
    ims=[]
    for p in paths:
        im=Image.open(p).convert('RGB'); w,h=im.size; nh=int(h*width/w); ims.append(im.resize((width,nh)))
    total=sum(im.height for im in ims); canvas=Image.new('RGB',(width,total),bg); y=0
    for im in ims: canvas.paste(im,(0,y)); y+=im.height
    canvas.save(outpath)
fig,ax=plt.subplots(figsize=(12,7)); ax.axis('off'); boxes=[(0.05,0.68,'Bulk A1\nTARGET-OS + GEO\nGlobal LMC test'),(0.38,0.68,'Single-cell A2\n5 samples\nCell-type coupling'),(0.71,0.68,'Spatial A2\nGSE299025\nCo-localization'),(0.38,0.20,'Reproducible L/M-high malignant state\nHK-PRKN | SIRT1-ATG | HDAC6-SQSTM1')]
for x,y,t in boxes: ax.add_patch(plt.Rectangle((x,y),0.24,0.16,facecolor='#eef3fb',edgecolor='#315b8a',linewidth=2)); ax.text(x+0.12,y+0.08,t,ha='center',va='center',fontsize=11)
for x in [0.29,0.62]: ax.annotate('',xy=(x+0.09,0.76),xytext=(x,0.76),arrowprops=dict(arrowstyle='->',lw=2,color='#333333'))
ax.annotate('',xy=(0.50,0.37),xytext=(0.50,0.67),arrowprops=dict(arrowstyle='->',lw=2,color='#333333')); ax.set_title('A1+A2 integrated study design',fontsize=16); fig.tight_layout(); fig.savefig(out/'Figure1.png',dpi=300); fig.savefig(out/'Figure1.pdf'); plt.close(fig)
stitch(['outputs/A1_week3/A1_week3_Gate1_forest.png','outputs/A1_week3/A1_week3_score_distributions.png'],out/'Figure2.png'); stitch(['outputs/A2_week6b/A2_week6b_summary.png'],out/'Figure3.png'); stitch(['outputs/A2_week7/A2_week7_summary.png'],out/'Figure4.png')
sp=pd.read_csv('outputs/A2_week8/A2_week8_spatial_correlations.tsv',sep='\t'); mat=sp.pivot(index=['score1','score2'],columns='sample',values='spearman'); plt.figure(figsize=(7,8)); sns.heatmap(mat,cmap='RdBu_r',center=0); plt.title('Spatial L/M-bridge correlations'); plt.tight_layout(); plt.savefig(out/'spatial_corr.png',dpi=300); plt.close(); stitch(['outputs/A2_week8/A2_week8_spatial_maps.png',str(out/'spatial_corr.png')],out/'Figure5.png'); stitch(['outputs/A1_A2_integration/A1_A2_integrated_model_v2.png'],out/'Figure6.png'); print('figure assets written')
