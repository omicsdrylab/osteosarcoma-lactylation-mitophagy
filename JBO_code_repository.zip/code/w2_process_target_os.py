from pathlib import Path
import pandas as pd, numpy as np, json
base=Path('work/A1/02_data/raw/TARGET_OS'); files=base/'files'
proc=Path('work/A1/02_data/processed'); proc.mkdir(parents=True,exist_ok=True)
man=pd.read_csv(base/'TARGET_OS_expression_files.csv').drop_duplicates('file_id').set_index('file_id')
counts=None; tpm=None; qc=[]
for i,(fid,row) in enumerate(man.iterrows(),1):
    p=files/row['file_name']
    df=pd.read_csv(p,sep='\t',comment='#',dtype={'gene_id':str,'gene_name':str,'gene_type':str,'unstranded':float,'tpm_unstranded':float})
    df=df[~df['gene_id'].astype(str).str.startswith('N_')].copy()
    df['gene_id_versioned']=df['gene_id']; df['gene_id']=df['gene_id'].str.split('.').str[0]
    df=df.drop_duplicates('gene_id')
    sid=row['sample_submitter_id']
    if counts is None:
        counts=df[['gene_id','gene_name','gene_type','unstranded']].rename(columns={'unstranded':sid}).set_index('gene_id')
        tpm=df[['gene_id','tpm_unstranded']].rename(columns={'tpm_unstranded':sid}).set_index('gene_id')
    else:
        counts[sid]=df.set_index('gene_id')['unstranded'].reindex(counts.index)
        tpm[sid]=df.set_index('gene_id')['tpm_unstranded'].reindex(tpm.index)
    c=df['unstranded'].fillna(0).clip(lower=0)
    mit=c[df['gene_name'].fillna('').str.startswith('MT-')].sum()
    rib=c[df['gene_name'].fillna('').str.match(r'^(RPS|RPL)')].sum()
    total=c.sum(); top10=c.nlargest(10).sum()
    qc.append({'sample_submitter_id':sid,'case_submitter_id':row['case_submitter_id'],'library_size':total,'detected_genes':int((c>0).sum()),'mitochondrial_fraction':mit/total if total else np.nan,'ribosomal_fraction':rib/total if total else np.nan,'top10_fraction':top10/total if total else np.nan})
    if i%20==0: print('parsed',i,flush=True)
counts.index.name='gene_id'; tpm.index.name='gene_id'
counts.to_csv(proc/'TARGET_OS_counts.tsv',sep='\t')
tpm.to_csv(proc/'TARGET_OS_tpm.tsv',sep='\t')
pd.DataFrame(qc).to_csv(proc/'TARGET_OS_sample_qc_raw.tsv',sep='\t',index=False)

j=json.load(open(base/'gdc_clinical_raw.json',encoding='utf-8'))
rows=[]
for h in j['data']['hits']:
    d=(h.get('demographic') or {}); dx=(h.get('diagnoses') or [{}])[0]; fu=h.get('follow_ups') or []
    days_first_event=[x.get('days_to_first_event') for x in fu if x.get('days_to_first_event') is not None]
    days_progression=[x.get('days_to_progression') for x in fu if x.get('days_to_progression') is not None]
    days_follow=[x.get('days_to_follow_up') for x in fu if x.get('days_to_follow_up') is not None]
    first_events=[x.get('first_event') for x in fu if x.get('first_event')]
    progression=[x.get('progression_or_recurrence') for x in fu if x.get('progression_or_recurrence')]
    event=0
    if d.get('vital_status')=='Dead' or any(str(x).lower() in {'relapse','progression','recurrence','death'} for x in first_events) or any(str(x).lower()=='yes' for x in progression) or dx.get('days_to_recurrence') is not None:
        event=1
    time_candidates=[]
    for v in [min(days_first_event) if days_first_event else None, min(days_progression) if days_progression else None, d.get('days_to_death'), dx.get('days_to_recurrence')]:
        if v is not None: time_candidates.append(float(v))
    efs_days=min(time_candidates) if event and time_candidates else (max(days_follow) if days_follow else dx.get('days_to_last_follow_up'))
    rows.append({'case_id':h.get('case_id'),'case_submitter_id':h.get('submitter_id'),'sex':d.get('sex_at_birth'),'race':d.get('race'),'ethnicity':d.get('ethnicity'),'vital_status':d.get('vital_status'),'age_at_index':d.get('age_at_index'),'days_to_death':d.get('days_to_death'),'age_at_diagnosis_days':dx.get('age_at_diagnosis'),'primary_diagnosis':dx.get('primary_diagnosis'),'metastasis_at_diagnosis':dx.get('metastasis_at_diagnosis'),'tumor_grade':dx.get('tumor_grade'),'tissue_or_organ_of_origin':dx.get('tissue_or_organ_of_origin'),'site_of_resection_or_biopsy':dx.get('site_of_resection_or_biopsy'),'days_to_recurrence':dx.get('days_to_recurrence'),'days_to_last_follow_up':dx.get('days_to_last_follow_up'),'first_event':';'.join([str(x) for x in first_events]) if first_events else '', 'progression_or_recurrence':';'.join([str(x) for x in progression]) if progression else '', 'efs_event':event,'efs_days':efs_days})
clin=pd.DataFrame(rows)
clin['metastasis_at_diagnosis_binary']=clin['metastasis_at_diagnosis'].map(lambda x: 1 if str(x).strip().lower().startswith('yes') else (0 if str(x).strip().lower().startswith('no') else np.nan))
clin.to_csv(proc/'TARGET_OS_clinical_flat.tsv',sep='\t',index=False)
sample_clin=pd.read_csv(base/'TARGET_OS_expression_files.csv')[['file_id','file_name','case_id','case_submitter_id','sample_submitter_id','sample_type','tissue_type','md5sum']].merge(clin,on=['case_id','case_submitter_id'],how='left')
sample_clin.to_csv(proc/'TARGET_OS_expression_clinical_linked.tsv',sep='\t',index=False)
print('matrix',counts.shape,'tpm',tpm.shape,'clinical',clin.shape)
print('event counts',clin['efs_event'].value_counts(dropna=False).to_dict())
print('metastasis at diagnosis',clin['metastasis_at_diagnosis_binary'].value_counts(dropna=False).to_dict())
print('RNA linked clinical rows',len(sample_clin),'cases with RNA',sample_clin.case_id.nunique())
