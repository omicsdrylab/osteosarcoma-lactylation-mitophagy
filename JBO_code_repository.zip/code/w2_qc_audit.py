from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
proc=Path('work/A1/02_data/processed'); figdir=Path('work/A1/06_figures'); figdir.mkdir(parents=True,exist_ok=True)
flags=[]; corr_summary=[]; pca_store={}
def top_var_matrix(df,n=2000):
    df=df.apply(pd.to_numeric,errors='coerce').dropna(axis=0,how='any')
    v=df.var(axis=1).sort_values(ascending=False).head(n).index
    return df.loc[v]
def sample_corr_flags(gse,mat):
    X=top_var_matrix(mat)
    corr=X.corr(method='pearson').values.copy()
    np.fill_diagonal(corr,np.nan)
    med=np.nanmedian(corr,axis=1)
    mean=np.nanmean(med); sd=np.nanstd(med,ddof=1)
    for s,val in zip(X.columns,med):
        flags.append({'dataset':gse,'sample_id':s,'median_sample_correlation':float(val),'outlier_flag':int(val < mean-4*sd)})
    corr_summary.append({'dataset':gse,'n_samples':mat.shape[1],'median_corr_mean':float(mean),'median_corr_sd':float(sd),'min_median_corr':float(np.nanmin(med)),'max_median_corr':float(np.nanmax(med))})
    return X,med
q=pd.read_csv(proc/'TARGET_OS_sample_qc_raw.tsv',sep='\t')
q['library_outlier']=(q.library_size < 10_000_000).astype(int); q['mito_outlier']=(q.mitochondrial_fraction > 0.25).astype(int); q['detected_outlier']=(q.detected_genes < 20000).astype(int); q['outlier_flag']=q[['library_outlier','mito_outlier','detected_outlier']].max(axis=1)
q.to_csv(proc/'TARGET_OS_sample_qc_flags.tsv',sep='\t',index=False)
counts=pd.read_csv(proc/'TARGET_OS_symbol_counts.tsv.gz',sep='\t',index_col=0,compression='gzip')
lib=counts.sum(axis=0).replace(0,np.nan); cpm=np.log2(counts.divide(lib,axis=1)*1e6+1)
X_target,med_target=sample_corr_flags('TARGET_OS',cpm)
f=pd.DataFrame(flags); f=f[f.dataset!='TARGET_OS']
tg=pd.DataFrame({'dataset':'TARGET_OS','sample_id':q.sample_submitter_id,'median_sample_correlation':med_target,'outlier_flag':q.outlier_flag.values})
f=pd.concat([f,tg],ignore_index=True); flags=f.to_dict('records')
pca=PCA(n_components=5,random_state=20261005); Z=pca.fit_transform(top_var_matrix(cpm).T.values); pcs=pd.DataFrame(Z[:,:5],columns=[f'PC{i+1}' for i in range(5)],index=cpm.columns)
meta=pd.read_csv(proc/'A1_harmonized_metadata.tsv',sep='\t'); tm=meta[meta.dataset=='TARGET_OS'].set_index('sample_id'); pcs=pcs.join(tm[['primary_event','sex','age_value']]); pcs['dist']=np.sqrt(((pcs.iloc[:,:5]-pcs.iloc[:,:5].mean())/pcs.iloc[:,:5].std()).pow(2).sum(axis=1)); pcs['pca_outlier']=(pcs['dist']>5).astype(int); pcs.to_csv(proc/'TARGET_OS_PCA.tsv',sep='\t')
# GEO cohorts
for gse in ['GSE21257','GSE39055','GSE33382','GSE16091','GSE14359']:
    mat=pd.read_csv(proc/f'{gse}_canonical_gene_matrix.tsv.gz',sep='\t',index_col=0,compression='gzip')
    X,med=sample_corr_flags(gse,mat)
    for s,val in zip(X.columns,med):
        flags.append({'dataset':gse,'sample_id':s,'median_sample_correlation':float(val),'outlier_flag':0})
corr_df=pd.DataFrame([x for x in corr_summary])
f=pd.DataFrame(flags).drop_duplicates(['dataset','sample_id'],keep='last')
f['outlier_flag']=0
for gse,g in f.groupby('dataset'):
    mean=g.median_sample_correlation.mean(); sd=g.median_sample_correlation.std(ddof=1)
    f.loc[g.index,'outlier_flag']=(g.median_sample_correlation < mean-4*sd).astype(int)
f.to_csv(proc/'A1_sample_outlier_flags.tsv',sep='\t',index=False)
corr_df.to_csv(proc/'A1_sample_correlation_summary.tsv',sep='\t',index=False)
# QC figure and report
fig,axs=plt.subplots(2,2,figsize=(12,9))
axs[0,0].hist(q.library_size/1e6,bins=20,color='#4c72b0'); axs[0,0].set_xlabel('Library size (million counts)'); axs[0,0].set_ylabel('Samples'); axs[0,0].set_title('TARGET-OS library size')
axs[0,1].hist(q.mitochondrial_fraction*100,bins=20,color='#dd8452'); axs[0,1].set_xlabel('Mitochondrial fraction (%)'); axs[0,1].set_ylabel('Samples'); axs[0,1].set_title('TARGET-OS mitochondrial fraction')
f.boxplot(column='median_sample_correlation',by='dataset',ax=axs[1,0],rot=45); axs[1,0].set_title('Sample median correlation'); axs[1,0].set_xlabel(''); axs[1,0].set_ylabel('Median Pearson correlation')
pcs=pd.read_csv(proc/'TARGET_OS_PCA.tsv',sep='\t',index_col=0)
for ev,color,label in [(0,'#4c72b0','No metastasis/relapse event'),(1,'#c44e52','Metastasis/relapse event')]:
    z=pcs[pcs.primary_event==ev]; axs[1,1].scatter(z.PC1,z.PC2,s=35,c=color,label=label,alpha=0.8)
axs[1,1].set_xlabel('PC1'); axs[1,1].set_ylabel('PC2'); axs[1,1].set_title('TARGET-OS PCA'); axs[1,1].legend(fontsize=8)
fig.suptitle('A1 Week 2 sample QC overview',fontsize=14); fig.tight_layout(rect=[0,0,1,0.96]); fig.savefig(figdir/'A1_week2_QC_overview.png',dpi=300); fig.savefig(figdir/'A1_week2_QC_overview.pdf'); plt.close(fig)
lines=['# A1 Week 2 QC and Batch Audit','','## TARGET-OS','',f"- RNA-seq samples: {q.shape[0]}",f"- Library size range: {q.library_size.min()/1e6:.1f}-{q.library_size.max()/1e6:.1f} million counts",f"- Detected genes range: {int(q.detected_genes.min())}-{int(q.detected_genes.max())}",f"- Mitochondrial fraction range: {q.mitochondrial_fraction.min():.3f}-{q.mitochondrial_fraction.max():.3f}",f"- Flagged samples by library/mito/detection rules: {int(q.outlier_flag.sum())}",f"- PCA outliers by distance >5 SD: {int(pcs.pca_outlier.sum())}",'','## GEO cohorts','']
for _,r in corr_df.iterrows():
    lines.append(f"- {r.dataset}: n={int(r.n_samples)}, median correlation mean={r.median_corr_mean:.3f}, min={r.min_median_corr:.3f}")
lines += ['','## Batch and overlap decisions','', '- RNA-seq and microarray cohorts are processed separately and will not be merged into one raw expression matrix.','- GSE42352 is a SuperSeries containing GSE33382 and therefore cannot be used as an independent validation cohort.','- GSE14359 raw intensities were log2-transformed and used only as a normal/MSC/osteoblast context dataset.','- GSE16091 has 77% primary mitophagy-program coverage; it may be used for L-score/overall-survival sensitivity analysis, but not as primary M-score validation.','- Primary mitophagy coverage is >91% in TARGET-OS, GSE21257, GSE33382, and GSE39055.','- Primary lactylation coverage is 100% in TARGET-OS, GSE21257, GSE33382, and GSE39055.','','## Outputs','', '- A1_sample_outlier_flags.tsv','- A1_sample_correlation_summary.tsv','- TARGET_OS_PCA.tsv','- A1_week2_QC_overview.png/pdf']
Path('work/A1/02_data/A1_QC_report.md').write_text('\n'.join(lines),encoding='utf-8')
print('QC done; flagged',int(q.outlier_flag.sum()),'TARGET-OS, PCA outliers',int(pcs.pca_outlier.sum()))
print(corr_df.to_string(index=False))

