from pathlib import Path
import pandas as pd, numpy as np, scanpy as sc, gc
from scipy.sparse import csr_matrix
from scipy.stats import spearmanr
from sklearn.neighbors import NearestNeighbors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
base=Path('work/A2'); gene=Path('work/A1/01_genesets'); lac=pd.read_csv(gene/'lactylation_genes_v1.tsv',sep='\t'); mit=pd.read_csv(gene/'mitophagy_genes_v1.tsv',sep='\t')
sets={'L_primary':lac.query('include_primary==1').gene.tolist(),'M_primary':mit.query('include_primary_GO==1').gene.tolist(),'HK_PRKN':['HK1','HK2','PKM','PRKN'],'HDAC6_SQSTM1':['HDAC6','SQSTM1'],'SIRT1_ATG':['SIRT1','ATG5','ATG7','MAP1LC3B','GABARAPL1'],'HIF1A_BNIP3':['HIF1A','BNIP3'],'Hypoxia':['HIF1A','VEGFA','SLC2A1','LDHA','PGK1','ENO1','HK2','PDK1','BNIP3','NDRG1','ADM','CA9','EGLN3','ANGPTL4'],'Proliferation':['MKI67','PCNA','TOP2A','CCNB1','CCNB2','CDK1','AURKA','AURKB','BIRC5','E2F1'],'Osteoblastic':['COL1A1','COL1A2','SPARC','ALPL','RUNX2','SP7','IBSP','SPP1','SATB2'],'Myeloid':['LYZ','CD68','CD14','FCGR3A','S100A8','S100A9','ITGAM','CSF1R'],'M2_TAM':['CD163','MRC1','MSR1','IL10','TGFB1','ARG1','VEGFA','CCL22'],'M1_Inflammatory':['TNF','IL1B','CXCL8','CXCL10','NFKB1','RELA','STAT1','CD80','CD86'],'AntigenPresentation':['HLA-DRA','HLA-DRB1','CD74','TAP1','B2M','PSMB9']}; samples={'PatientA':base/'incoming/GSE299025/PatientA','PatientB':base/'incoming/GSE299025/PatientB'}
def score_matrix(a):
    scores={}
    for name,genes in sets.items():
        gs=[g for g in genes if g in a.var_names]
        if len(gs)<2: scores[name]=np.full(a.n_obs,np.nan); continue
        X=np.asarray(a[:,gs].X.todense()); mu=X.mean(0); sd=X.std(0); sd[sd==0]=1; scores[name]=((X-mu)/sd).mean(1)
    return pd.DataFrame(scores,index=a.obs_names)
def build_graph(coords,k=6):
    nn=NearestNeighbors(n_neighbors=min(k+1,len(coords))).fit(coords); dist,idx=nn.kneighbors(coords); rows=[]; cols=[]; vals=[]
    for i in range(len(coords)):
        for j,d in zip(idx[i,1:],dist[i,1:]): rows.append(i); cols.append(j); vals.append(np.exp(-(d/(np.median(dist[:,1:])+1e-9))**2))
    W=csr_matrix((vals,(rows,cols)),shape=(len(coords),len(coords))); return (W+W.T)/2
def morans(x,W):
    x=np.asarray(x,dtype=float); x=x-x.mean(); denom=(x*x).sum(); return float(len(x)/W.sum()*(x@(W@x))/denom) if denom>0 else np.nan
all_spots=[]; moran_rows=[]; corr_rows=[]; neigh_rows=[]; plot_data={}
for sample,path in samples.items():
 print('processing',sample,flush=True); a=sc.read_10x_mtx(path,var_names='gene_symbols',make_unique=True); a.var_names=a.var_names.astype(str).str.upper(); a.var_names_make_unique(); sc.pp.filter_cells(a,min_genes=100); sc.pp.filter_genes(a,min_cells=3); pos=pd.read_csv(path/'tissue_positions_list.csv.gz',header=None,names=['barcode','in_tissue','array_row','array_col','pxl_row','pxl_col']); pos=pos[pos.in_tissue==1].set_index('barcode'); common=a.obs_names.intersection(pos.index); a=a[common].copy(); pos=pos.loc[common]; sc.pp.normalize_total(a,target_sum=1e4); sc.pp.log1p(a); scores=score_matrix(a); coords=pos[['pxl_col','pxl_row']].values; W=build_graph(coords); plot_data[sample]=(coords,scores.copy()); out=scores.copy(); out.insert(0,'sample',sample); out.insert(1,'barcode',out.index); all_spots.append(out)
 for name in scores.columns: moran_rows.append({'sample':sample,'score':name,'morans_I':morans(scores[name],W)})
 for s1,s2 in [('L_primary','M_primary'),('L_primary','HK_PRKN'),('L_primary','HDAC6_SQSTM1'),('L_primary','SIRT1_ATG'),('M_primary','HK_PRKN'),('M_primary','HDAC6_SQSTM1'),('M_primary','SIRT1_ATG'),('L_primary','Myeloid'),('L_primary','M2_TAM'),('M_primary','Myeloid'),('M_primary','M2_TAM')]: rho,p=spearmanr(scores[s1],scores[s2]); corr_rows.append({'sample':sample,'score1':s1,'score2':s2,'spearman':rho,'p_value':p})
 rng=np.random.default_rng(20261005)
 for focal,target in [('L_primary','Myeloid'),('L_primary','M2_TAM'),('M_primary','Myeloid'),('M_primary','M2_TAM'),('HK_PRKN','Myeloid'),('HDAC6_SQSTM1','M2_TAM')]:
  f=scores[focal]>scores[focal].quantile(.75); t=scores[target]>scores[target].quantile(.75); neigh=W.copy(); neigh.data[:]=1; neigh.setdiag(0); neigh.eliminate_zeros(); frac=np.asarray((neigh@t.astype(float))).ravel()/np.asarray(neigh.sum(1)).ravel(); obs=frac[f].mean(); perm=[]
  for _ in range(1000):
   tp=rng.permutation(t.values); perm.append((np.asarray((neigh@tp.astype(float))).ravel()/np.asarray(neigh.sum(1)).ravel())[f].mean())
  perm=np.array(perm); pval=(1+np.sum(perm>=obs))/(1+len(perm)); neigh_rows.append({'sample':sample,'focal':focal,'target':target,'observed_fraction':obs,'perm_mean':perm.mean(),'empirical_p':pval})
 del a; gc.collect()
pd.concat(all_spots,ignore_index=True).to_csv(base/'A2_week8_spatial_spot_scores.tsv.gz',sep='\t',index=False,compression='gzip'); pd.DataFrame(moran_rows).to_csv(base/'A2_week8_spatial_morans_i.tsv',sep='\t',index=False); pd.DataFrame(corr_rows).to_csv(base/'A2_week8_spatial_correlations.tsv',sep='\t',index=False); pd.DataFrame(neigh_rows).to_csv(base/'A2_week8_spatial_neighbor_enrichment.tsv',sep='\t',index=False)
scores_to_plot=['L_primary','M_primary','HK_PRKN','HDAC6_SQSTM1','SIRT1_ATG','Myeloid','M2_TAM']; fig,axs=plt.subplots(len(samples),len(scores_to_plot),figsize=(4*len(scores_to_plot),4*len(samples)))
for i,(sample,(coords,scdf)) in enumerate(plot_data.items()):
 for j,name in enumerate(scores_to_plot):
  ax=axs[i,j] if len(samples)>1 else axs[j]; q=scdf[name].quantile([.02,.98]).values; ax.scatter(coords[:,0],-coords[:,1],c=scdf[name].clip(*q),s=8,cmap='viridis'); ax.set_title(f'{sample} {name}'); ax.axis('off')
fig.tight_layout(); fig.savefig(base/'A2_week8_spatial_maps.png',dpi=250); fig.savefig(base/'A2_week8_spatial_maps.pdf'); plt.close(fig); print('spatial done')

