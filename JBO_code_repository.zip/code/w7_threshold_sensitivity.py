from pathlib import Path
import pandas as pd, numpy as np
from scipy.stats import mannwhitneyu

root=Path(r'C:\Users\常昆\Documents\Codex\2026-10-02\w')
df=pd.read_csv(root/'work/A2/A2_week7_cell_states.tsv.gz',sep='\t')
axes=['HK_PRKN','HDAC6_SQSTM1','SIRT1_ATG']
rows=[]
for q in [0.20,0.25,0.30,0.33]:
    for sample,g in df.groupby('sample'):
        g=g[g.cell_type=='Malignant_Osteoblastic'].copy()
        for anchor in ['L_primary','M_primary']:
            hi=g[g[anchor]>=g[anchor].quantile(1-q)]
            lo=g[g[anchor]<=g[anchor].quantile(q)]
            for ax in axes:
                u,p=mannwhitneyu(hi[ax],lo[ax],alternative='two-sided')
                delta=2*u/(len(hi)*len(lo))-1
                rows.append({'quantile':q,'sample':sample,'anchor':anchor,'axis':ax,'n_high':len(hi),'n_low':len(lo),'cliff_delta':delta,'p_value':p,'direction':'higher_in_high' if delta>0 else 'lower_in_high'})
out=pd.DataFrame(rows)
out.to_csv(root/'work/A2/A2_week7_threshold_sensitivity.tsv',sep='\t',index=False)
summary=out.groupby(['quantile','anchor','axis']).agg(n_samples=('sample','nunique'),same_direction=('direction',lambda x:(x=='higher_in_high').sum()),min_delta=('cliff_delta','min'),median_delta=('cliff_delta','median'),max_delta=('cliff_delta','max')).reset_index()
summary.to_csv(root/'work/A2/A2_week7_threshold_sensitivity_summary.tsv',sep='\t',index=False)
print(summary.to_string(index=False))
