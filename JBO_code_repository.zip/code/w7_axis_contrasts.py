from pathlib import Path
import pandas as pd, numpy as np
from scipy.stats import mannwhitneyu
base=Path('work/A2'); d=pd.read_csv(base/'A2_week7_cell_states.tsv.gz',sep='\t'); axes=['L_primary','M_primary','HK_PRKN','HDAC6_SQSTM1','SIRT1_ATG','HIF1A_BNIP3']; rows=[]
for sample,g in d.groupby('sample'):
    if set(g.cell_type)>= {'Malignant_Osteoblastic','Myeloid'}:
        for ax in axes:
            m=g.loc[g.cell_type=='Malignant_Osteoblastic',ax].dropna(); my=g.loc[g.cell_type=='Myeloid',ax].dropna()
            if len(m)>=30 and len(my)>=30:
                u,p=mannwhitneyu(m,my,alternative='two-sided'); delta=2*u/(len(m)*len(my))-1; rows.append({'sample':sample,'axis':ax,'n_malignant':len(m),'n_myeloid':len(my),'mean_malignant':m.mean(),'mean_myeloid':my.mean(),'difference':m.mean()-my.mean(),'cliff_delta':delta,'p_value':p,'direction':'higher_in_malignant' if delta>0 else 'higher_in_myeloid'})
r=pd.DataFrame(rows); r.to_csv(base/'A2_week7_axis_malignant_vs_myeloid.tsv',sep='\t',index=False); print(r.sort_values(['axis','sample']).to_string(index=False))
