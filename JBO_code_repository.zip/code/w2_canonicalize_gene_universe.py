from pathlib import Path
import pandas as pd, requests
proc=Path('work/A1/02_data/processed'); gene=Path('work/A1/01_genesets')
lac=pd.read_csv(gene/'lactylation_genes_v1.tsv',sep='\t')
mit=pd.read_csv(gene/'mitophagy_genes_v1.tsv',sep='\t')
canon=sorted(set(lac.gene)|set(mit.gene))
r=requests.post('https://mygene.info/v3/query',data={'q':'\n'.join(canon),'scopes':'symbol','fields':'symbol,alias,ensembl.gene','species':'human'},timeout=90)
r.raise_for_status(); ann=r.json()
alias_rows=[]; alias_to_canon={}
for x in ann:
    c=x.get('symbol'); aliases=x.get('alias',[]); aliases=[aliases] if isinstance(aliases,str) else aliases or []
    ens=x.get('ensembl',{}); ens=ens[0] if isinstance(ens,list) and ens else ens; ens=ens.get('gene') if isinstance(ens,dict) else None
    alias_rows.append({'canonical':c,'aliases':';'.join([str(a) for a in aliases]),'ensembl_gene':ens})
    if c:
        alias_to_canon[str(c).upper()]=c
        for a in aliases: alias_to_canon[str(a).upper()]=c
pd.DataFrame(alias_rows).to_csv(proc/'A1_gene_alias_map.tsv',sep='\t',index=False)
def canonicalize(df):
    df=df.copy(); df.index=df.index.astype(str).str.upper(); df['_canonical']=df.index.map(alias_to_canon); df=df[df['_canonical'].notna()]
    vals=df.drop(columns=['_canonical']).apply(pd.to_numeric,errors='coerce'); df['_mean']=vals.mean(axis=1,skipna=True)
    df=df.sort_values('_mean',ascending=False); df=df[~df['_canonical'].duplicated(keep='first')]; return df.set_index('_canonical').drop(columns=['_mean']).rename_axis('gene')
counts=pd.read_csv(proc/'TARGET_OS_counts.tsv',sep='\t',index_col='gene_id'); tpm=pd.read_csv(proc/'TARGET_OS_tpm.tsv',sep='\t',index_col='gene_id')
sample_cols=[x for x in counts.columns if x.startswith('TARGET-')]; c=counts[sample_cols].copy(); t=tpm[sample_cols].copy(); c.index=counts['gene_name'].fillna('').astype(str); t.index=counts['gene_name'].fillna('').astype(str); c=c[c.index!='']; t=t[t.index!='']
c['_mean']=c.mean(axis=1); t['_mean']=t.mean(axis=1); c=c.sort_values('_mean',ascending=False); c=c[~c.index.duplicated(keep='first')].drop(columns=['_mean']); t=t.sort_values('_mean',ascending=False); t=t[~t.index.duplicated(keep='first')].drop(columns=['_mean'])
c.to_csv(proc/'TARGET_OS_symbol_counts.tsv.gz',sep='\t',compression='gzip'); t.to_csv(proc/'TARGET_OS_symbol_tpm.tsv.gz',sep='\t',compression='gzip')
sets=[('L_primary',lac.query('include_primary==1').gene.tolist()),('L_core',lac.query('include_core==1').gene.tolist()),('L_context',lac.query('include_context==1').gene.tolist()),('M_primary',mit.query('include_primary_GO==1').gene.tolist()),('M_extended',mit.query('include_extended_union==1').gene.tolist())]
coverage=[]
for gse in ['GSE21257','GSE33382','GSE42352','GSE39055','GSE16091','GSE14359']:
    m=pd.read_csv(proc/f'{gse}_gene_matrix.tsv.gz',sep='\t',index_col=0,compression='gzip'); cm=canonicalize(m); cm.to_csv(proc/f'{gse}_canonical_gene_matrix.tsv.gz',sep='\t',compression='gzip')
    for setname,genes in sets:
        present=[g for g in genes if g in cm.index]; coverage.append({'dataset':gse,'program':setname,'set_size':len(genes),'present':len(present),'coverage':len(present)/len(genes),'missing':';'.join([g for g in genes if g not in cm.index])})
for setname,genes in sets:
    present=[g for g in genes if g in c.index]; coverage.append({'dataset':'TARGET_OS','program':setname,'set_size':len(genes),'present':len(present),'coverage':len(present)/len(genes),'missing':';'.join([g for g in genes if g not in c.index])})
pd.DataFrame(coverage).to_csv(proc/'A1_geneset_coverage.tsv',sep='\t',index=False)
print('canonical genes',len(alias_rows),'alias keys',len(alias_to_canon))
print(pd.DataFrame(coverage).to_string(index=False))

