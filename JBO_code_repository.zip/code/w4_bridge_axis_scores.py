from pathlib import Path
import pandas as pd, numpy as np, statsmodels.api as sm
from scipy.stats import rankdata
proc=Path('work/A1/02_data/processed'); out=Path('work/A1/04_bulk')
axes={'HK1_HK2_PKM_PRKN':['HK1','HK2','PKM','PRKN'],'HDAC6_SQSTM1':['HDAC6','SQSTM1'],'SIRT1_ATG':['SIRT1','ATG5','ATG7','MAP1LC3B','GABARAPL1'],'HIF1A_BNIP3':['HIF1A','BNIP3'],'EP300_ATG7':['EP300','ATG7'],'HDAC1_HDAC2_OGT_PHB2':['HDAC1','HDAC2','OGT','PHB2']}
rows=[]
def score_mat(mat,ds):
    mat.index=mat.index.astype(str).str.upper(); mat=mat[~mat.index.duplicated(keep='first')]; X=mat.apply(pd.to_numeric,errors='coerce'); out=[]
    for s in X.columns:
        vals=X[s].values.astype(float); ranks=rankdata(vals,method='average')/len(vals); r={'dataset':ds,'sample_id':s}
        for name,genes in axes.items():
            present=[g.upper() for g in genes if g.upper() in X.index]; r[name]=float(np.mean(ranks[[X.index.get_loc(g) for g in present]])-0.5) if present else np.nan; r[name+'_coverage']=len(present)/len(genes)
        out.append(r)
    return pd.DataFrame(out)
c=pd.read_csv(proc/'TARGET_OS_symbol_counts.tsv.gz',sep='\t',index_col=0,compression='gzip'); lib=c.sum(axis=0).replace(0,np.nan); cpm=np.log2(c.divide(lib,axis=1)*1e6+1); rows.append(score_mat(cpm,'TARGET_OS')); del c,cpm
for gse in ['GSE21257','GSE39055','GSE33382','GSE16091']:
    m=pd.read_csv(proc/f'{gse}_gene_matrix_upper.tsv.gz',sep='\t',index_col=0,compression='gzip'); rows.append(score_mat(m,gse)); del m
s=pd.concat(rows,ignore_index=True); s.to_csv(out/'A1_bridge_axis_scores_raw.tsv',sep='\t',index=False)
for c in axes:
    s[c+'_z']=np.nan
    for ds,g in s.groupby('dataset'):
        mu=g[c].mean(); sd=g[c].std(ddof=1); s.loc[g.index,c+'_z']=(g[c]-mu)/sd
s.to_csv(out/'A1_bridge_axis_scores_z.tsv',sep='\t',index=False); meta=pd.read_csv(proc/'A1_harmonized_metadata.tsv',sep='\t'); cohort_events={'TARGET_OS':'primary_event','GSE21257':'metastasis_event','GSE39055':'recurrence_event','GSE33382':'metastasis_event','GSE16091':'death_event'}; res=[]
for ds,ev in cohort_events.items():
    m=meta[(meta.dataset==ds)&meta[ev].notna()][['sample_id',ev,'sex','age_value']]; d=s[s.dataset==ds].merge(m,on='sample_id'); d=d[d[ev].notna()].copy(); d['sex_male']=(d.sex.astype(str).str.lower()=='male').astype(float); d['age_z']=(d.age_value-d.age_value.mean())/d.age_value.std(ddof=1)
    for axis in axes:
        dd=d[[ev,axis+'_z','sex_male','age_z']].apply(pd.to_numeric,errors='coerce').dropna()
        if dd.shape[0]<15: continue
        for model_name,cols in [('unadjusted',[axis+'_z']),('adjusted',[axis+'_z','sex_male','age_z'])]:
            X=sm.add_constant(dd[cols].astype(float)); model=sm.GLM(dd[ev].astype(float),X,family=sm.families.Binomial()).fit(); beta=model.params[axis+'_z']; ci=model.conf_int().loc[axis+'_z']; res.append({'dataset':ds,'event':ev,'axis':axis,'model':model_name,'n':len(dd),'events':int(dd[ev].sum()),'OR_per_SD':np.exp(beta),'CI_low':np.exp(ci[0]),'CI_high':np.exp(ci[1]),'p_value':model.pvalues[axis+'_z'],'direction':'positive' if beta>0 else 'negative'})
r=pd.DataFrame(res); r.to_csv(out/'A1_bridge_axis_associations.tsv',sep='\t',index=False); print(r[r.model=='unadjusted'].sort_values(['axis','dataset']).to_string(index=False))
