Cell-state-associated lactylation-mitophagy coupling and bridge-axis activation in osteosarcoma: a bulk, single-cell, and spatial transcriptomic study

## Abstract

**Background** Lactylation and mitophagy have been studied separately in osteosarcoma. Whether they form a coordinated tissue program remains unclear.

**Methods** We integrated bulk cohorts (TARGET-OS, GSE21257, GSE39055, GSE33382, GSE16091), five single-cell samples (GSE152048, GSE162454, GSE318840), and two spatial transcriptomic samples (GSE299025). Bulk analysis was prespecified as a negative-control layer, and single-cell and spatial analyses were used to identify state-associated and spatial patterns. Bridge axes were prioritized for drug hypothesis generation.

**Results** Bulk lactylation scores were nominally associated with metastasis or recurrence in two external cohorts after adjustment for sex and age. Mitophagy scores and the multiplicative coupling score did not replicate. Single-cell analysis showed stronger L-M correlations in malignant/osteoblastic cells than in myeloid cells in datasets with adequate myeloid representation. L/M-high malignant cells consistently co-activated HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 across five samples. In two Visium samples, L and M scores were spatially autocorrelated and correlated with these axes. Under a label-permutation model, L/M-high spots were more often adjacent to M2/TAM-high spots; because this model does not preserve spatial autocorrelation, we interpret this result as descriptive.

**Conclusions** Bulk transcriptomes did not support global coupling, whereas L/M-associated bridge axes were observed within malignant-cell states and in two spatial samples. These results provide a bounded, state-associated hypothesis for further testing.

**Keywords:** osteosarcoma; lactylation; mitophagy; single-cell transcriptomics; spatial transcriptomics; tumor microenvironment

## Introduction

Osteosarcoma is the most common primary malignant bone tumor in children and adolescents [1-2]. Treatment has changed little over recent decades, and metastatic or recurrent disease remains associated with poor prognosis [1,3-5]. Large-scale genomic studies have not identified recurrent, targetable driver mutations in most patients. Attention has therefore moved toward metabolic and epigenetic programs that link the tumor microenvironment to malignant-cell state [3-7].

Lactate is a glycolytic product and a substrate for lysine lactylation, a post-translational modification that can affect chromatin and non-histone proteins [8-10]. Subsequent studies identified lactylation erasers and readers, including HDAC1-3 and SIRT1/3 [11-12] and BRD9 and DPF2 [10,13]. In osteosarcoma, lactylation has been linked to metabolic reprogramming, immune modulation, and chemotherapy response. Reported axes include DHX9 K1024 lactylation [14], cGAS lactylation [15], HDGF-mediated metabolic reprogramming [16], KAT2A-H3K18la [17], a lactylation-related signature [18], PFKP/HIF-1α/H3K18la [19], and a high-lactylation malignant state [20]. Mitophagy controls mitochondrial quality through general pathways such as BNIP3/NIX, FUNDC1, PHB2, and PINK1-PRKN-SQSTM1 [21-26]. In osteosarcoma, mitophagy has been linked to progression and chemotherapy response through BNIP3 [27], OMA1 [28], TIMM23 [29], SIRT3-PINK1-PRKN [30], GABARAP [31], and intercellular crosstalk [32]. Outside osteosarcoma, direct links between lactylation and mitophagy include Tufm K286 lactylation [33], ALDH2 lactylation with PHB2 degradation [34], PGK1 K361 lactylation in bone [35], H3K18la-PRKN in M2 macrophage polarization [36], HNRNPF-Parkin-mediated mitophagy [37], p300-H3K18la-dependent mitophagy inhibition [38], Numb/Parkin-related histone lactylation [39], and USP7 lactylation with PINK1 stabilization [40].

Together, these studies support a plausible but untested link between lactylation and mitophagy in osteosarcoma [33-40]. Prior osteosarcoma studies have reported lactylation-related and hypoxia/lactate-metabolism signatures [18,20,41], but these scores are prognostic rather than mechanistic. We therefore tested whether the two programs form a coordinated program across bulk, single-cell, and spatial data, and whether any coupling is confined to specific cell states.

We integrated bulk osteosarcoma cohorts, single-cell transcriptomes, and spatial transcriptomes. Bulk analysis served as a negative-control layer, and single-cell and spatial analyses were used to identify state-associated and spatial patterns. Global LMC was not supported in bulk tissue, whereas L-M coupling and selected bridge axes were observed in malignant/osteoblastic cell states and in two spatial samples. These findings support a state-associated hypothesis for prioritizing HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1.

## Results

### Bulk lactylation and mitophagy programs are not globally coupled

Figure 1 summarizes the study design and analysis layers. We first assembled a curated lactylation program and a mitophagy program from GO:0000423 and KEGG hsa04137. STRING analysis showed that the combined programs formed a highly interconnected network, but the two programs were modular rather than globally fused. Cross-program connectivity was enriched at medium-confidence STRING scores (score >= 400: 72 observed cross edges versus 39.3 expected, Z = 4.36, empirical P = 0.0002) but not at high-confidence scores (score >= 700: 15 observed versus 14.6 expected, Z = 0.10, P = 0.48). HDAC6 was shared between programs and was treated as a bridge node rather than included in the primary cross-group test.

We then evaluated bulk transcriptomes (Figure 2). In TARGET-OS, the primary endpoint was a composite metastasis or relapse/progression event (38 events and 50 non-events among 88 RNA-seq samples). External evaluation used GSE21257 (34 metastatic events and 19 non-events), GSE39055 (18 recurrences and 19 non-recurrences), and GSE33382 (34 metastases within five years and 19 non-metastases among 53 annotated biopsies).

The lactylation program showed a directionally consistent association with the primary endpoint in GSE21257 and GSE33382 (OR 1.95, 95% CI 1.04-3.67, P = 0.037; OR 1.97, 95% CI 1.04-3.72, P = 0.037). These associations persisted after adjustment for sex and age. The mitophagy program alone was not significant in any external cohort, and the multiplicative LMC score was not associated with the endpoint. Thus, bulk transcriptomes did not support a global coupling phenotype. In a raw-count analysis adjusted for sex and age, DESeq2 identified 431 genes at FDR < 0.05 and 4,033 genes at nominal P < 0.05.

### Single-cell analysis reveals malignant-cell-enriched L-M coupling

Because bulk averaging can obscure cell-type-specific programs, we analyzed five osteosarcoma single-cell samples from GSE152048, GSE162454, and GSE318840. GSE152048 was reported by Zhou et al. [42], and other osteosarcoma single-cell studies support malignant-cell heterogeneity and microenvironmental stratification [43-47]. Marker-based annotation identified malignant/osteoblastic, myeloid, fibroblast, endothelial, T/NK, B/plasma, and chondrocyte compartments, with substantial variation in composition across samples.

We calculated L and M scores per cell and correlated them within cell types (Figure 3). Malignant/osteoblastic cells showed stronger L-M correlations than myeloid cells in datasets with adequate myeloid representation. The correlations were 0.378 versus 0.097 in GSE152048 BC2, 0.279 versus 0.084 in GSE152048 BC3, and 0.566 versus 0.231 in GSE162454 OS_4. In GSE162454, malignant-cell correlations were also stronger than those in fibroblasts, endothelial cells, and T/NK cells. In GSE318840, malignant cells showed positive L-M correlations (r = 0.185 in treated and r = 0.284 in recurrent samples), but no adequate myeloid contrast was available. These correlations are descriptive because cells within a sample are not independent biological replicates.

### L/M-high malignant states co-activate specific bridge axes

We next asked whether the coupling was concentrated in a specific malignant-cell state. Within malignant/osteoblastic cells, we defined L-high and M-high cells using the upper quartile and compared them with the lower quartile (Figure 4). Three axes were consistently elevated across all five samples: HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1. The same direction was observed when the percentile threshold was varied between 20% and 33% (Supplementary Table S1).

For HK-PRKN, Cliff's delta for L-high versus L-low malignant cells was 0.740 in GSE152048 BC2, 0.588 in GSE152048 BC3, 0.713 in GSE162454 OS_4, 0.313 in GSE318840 Treated1, and 0.417 in GSE318840 Recurrent1. SIRT1-ATG and HDAC6-SQSTM1 showed the same direction in all five samples, with the strongest effects in GSE162454 OS_4. HIF1A-BNIP3 was higher in L-high malignant cells across all five samples, but its M-high pattern was inconsistent.

L and M scores were higher in malignant cells than in myeloid cells in all three datasets with adequate myeloid representation. Individual bridge axes were context-dependent: HK-PRKN was higher in malignant cells in GSE152048 but higher in myeloid cells in GSE162454, and HDAC6-SQSTM1 was higher in malignant cells in GSE152048 BC2 but higher in myeloid cells in GSE162454. The consistent unit was therefore the L/M-high malignant-cell state, not malignant cells in general.

### Spatial transcriptomics supports L/M-bridge-axis co-localization

To test whether the malignant-cell state was spatially organized, we analyzed two Visium samples from GSE299025 [48] (Figure 5). L and M scores showed positive spatial autocorrelation in both patients (L Moran's I = 0.353 and 0.221; M Moran's I = 0.369 and 0.347). Hypoxia and osteoblastic programs were also spatially structured.

Spot-level correlations were positive in both patients. In PatientA and PatientB, respectively, L-M correlations were 0.603 and 0.441; L-HK-PRKN correlations were 0.485 and 0.425; L-HDAC6-SQSTM1 correlations were 0.376 and 0.328; and L-SIRT1-ATG correlations were 0.417 and 0.261. M scores showed similar positive correlations with all three axes.

Under a label-permutation model, L/M-high spots were more often adjacent to M2/TAM-high spots in both patients (observed neighbor fraction approximately 0.29 versus permutation mean 0.25). PatientB also showed enrichment of L/M-high spots near myeloid-high spots. This permutation does not explicitly preserve spatial autocorrelation, so we interpret the neighbor pattern as descriptive rather than as a population-level test result.

### Bridge-axis-informed drug prioritization

The bridge axes identified in single-cell and spatial analyses were mapped to target-level pharmacological hypotheses (Figure 6). HDAC6-SQSTM1 was prioritized for HDAC6-directed strategies [49]. HK-PRKN was prioritized for glycolytic HK2 inhibition and mitochondrial quality-control modulation [50-51]. SIRT1-ATG was retained at moderate priority because SIRT1 modulation is context-dependent and indirect [11,52]. These hypotheses require experimental validation, and no causal claim is made from the transcriptomic or spatial associations.

## Discussion

This study tested whether lactylation and mitophagy form a coordinated program in osteosarcoma. Bulk transcriptomes did not support a reproducible global coupling phenotype, although lactylation scores showed nominal associations in two external cohorts. Prior lactylation-related and hypoxia/lactate-metabolism signatures [18,20,41] were designed for prognosis rather than mechanistic coupling, so the present bulk result does not contradict them directly. The signal appeared when the analysis was resolved by cell type and spatial location.

L-M coupling was stronger in malignant/osteoblastic cells than in myeloid cells in datasets with adequate myeloid representation, but it was not malignant-cell exclusive. The data support an L/M-high malignant state in which specific bridge axes are co-activated. HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 were consistently elevated in L-high and M-high malignant cells across five samples. These patterns are consistent with prior evidence linking PRKN-dependent mitophagy to M2 polarization [36], H3K18la to Parkin-mediated mitophagy [37], and p300-H3K18la to mitophagy inhibition [38]. Additional direct linkages include Tufm, ALDH2-PHB2, and bone PGK1 lactylation [33-35]. SIRT1 and HDAC6 family enzymes can also modulate lactylation state [11,39-40].

Spatial analysis showed that L and M programs were spatially autocorrelated and that their spot-level signals correlated with the three bridge axes in both Visium samples. L/M-high regions were also surrounded by M2/TAM-high spots. Because the label-permutation test and the spatial correlations are based on two patients and do not fully account for tissue architecture, these findings are descriptive. The pattern is consistent with studies showing that M2-polarized macrophages accompany PRKN-dependent mitophagy and that osteosarcoma cells can promote M2 polarization [36,53-54]. A separate spatial study of osteosarcoma pulmonary metastases reported regionally distinct immunosuppressive microenvironments [55].

The study has limitations. Bulk associations for the lactylation program were nominal and did not survive conservative multiple-testing correction. The single-cell analysis used five samples that passed quality thresholds rather than every available sample, and the datasets differ in platform, treatment status, and cell composition. Cell-type labels were marker-based, and spatial spots contain mixtures of cells. The spatial analysis used two patients and a label-permutation model that does not fully preserve spatial autocorrelation. Drug prioritization was knowledge-based and did not use LINCS/CMap connectivity analysis. The study identifies association and co-localization rather than causality.

Full-sample single-cell integration, orthogonal protein-lactylation measurements, and targeted perturbation of HK2, HDAC6, or SIRT1 would help test the proposed axes. Prior studies support these targets [49-52], but the present results remain a state-associated hypothesis rather than a validated mechanism.

## Methods

### Bulk datasets and preprocessing

TARGET-OS open STAR-Counts files were downloaded from the GDC. Gene expression matrices were linked to clinical metadata at the patient level. The primary endpoint was a composite metastasis or relapse/progression event. GSE21257, GSE39055, GSE33382, and GSE16091 were processed from GEO series matrices. GSE42352 was excluded from independent validation because it is a SuperSeries containing GSE33382. RNA-seq and microarray cohorts were processed separately.

### Gene programs and scoring

A 28-gene lactylation-associated program was curated from writers, erasers, readers, and lactate production or transport genes [8-13]. Mitophagy genes were derived from GO:0000423, with a sensitivity set that also included KEGG hsa04137 [21-26]. Bulk and single-cell module scores were computed using rank-based single-sample enrichment and standardized within cohort. L and M denote the lactylation and mitophagy scores, respectively, and bridge axes denote co-expression pairs spanning the two programs. A multiplicative LMC score was calculated as z(L) × z(M). Threshold sensitivity for L-high and M-high states was assessed at the 20th, 25th, 30th, and 33rd percentiles. The primary endpoint was locked before association testing.

### Bulk association analysis

Logistic regression was used to test associations between standardized scores and the locked endpoint. Sex- and age-adjusted models were used as sensitivity analyses. Effect sizes are reported as odds ratios per standard deviation with 95% confidence intervals. Nominal and FDR-adjusted P values are reported separately. Bulk differential expression used PyDESeq2 on raw STAR counts with a ~ condition + sex + age design, independent filtering, and Benjamini-Hochberg correction. This analysis identified 431 genes at FDR < 0.05 and 4,033 genes at nominal P < 0.05.

### Single-cell datasets and cell-type annotation

GSE152048 [42], GSE162454, and GSE318840 were processed as 10x matrices. Samples were processed one at a time to remain within a 16 GB memory limit. Cells were filtered with a minimum of 200 detected genes, and genes were retained if detected in at least three cells. Counts were normalized to 10,000 per cell and log-transformed. Major cell types were annotated with marker programs for malignant/osteoblastic, osteoprogenitor/MSC, chondrocyte, myeloid, T/NK, B/plasma, endothelial, and fibroblast compartments. KMeans clustering on principal components was used for malignant and myeloid substates. The five samples that passed these quality thresholds and had adequate malignant and myeloid cells were included; sample selection was independent of L/M scores and outcome.

### Single-cell state and bridge-axis analysis

Per-cell L, M, hypoxia, proliferation, EMT, osteoblastic, M1, M2/TAM, antigen-presentation, and stemness scores were computed from gene-wise standardized expression. Malignant and myeloid cells were analyzed separately. L-high and M-high cells were defined as the upper quartile within each sample and compared with the lower quartile; sensitivity analyses used 20th, 25th, 30th, and 33rd percentiles. Cliff's delta and Mann-Whitney tests were used for descriptive effect sizes. Cell-level P values were not used for biological inference because cells within a sample are not independent replicates.

### Spatial transcriptomics

GSE299025 [48] PatientA and PatientB Visium matrices and tissue-position files were processed without images. Spots were normalized and log-transformed. L, M, bridge-axis, hypoxia, osteoblastic, myeloid, M2/TAM, M1, and antigen-presentation scores were calculated. Moran's I was computed using a six-nearest-neighbor spatial graph with Gaussian weights. Spot-level correlations used Spearman correlation. Neighborhood enrichment compared the fraction of high-target neighbors around high-focal spots with 1,000 label permutations. Because this permutation does not explicitly preserve spatial autocorrelation, these results were treated as descriptive.

### Drug prioritization

Target-level drug hypotheses were generated for HK2, PRKN/PINK1, SIRT1, ATG7, HDAC6, and SQSTM1 [49-52]. Development stage and rationale were recorded for each target. These are hypothesis-generating candidates and were not tested experimentally.

## Data and code availability

All datasets are public. TARGET-OS data are available from the GDC. GEO datasets include GSE21257, GSE39055, GSE33382, GSE16091, GSE152048, GSE162454, GSE318840, and GSE299025. The analysis code and derived summary tables are available at https://github.com/omicsdrylab/osteosarcoma-lactylation-mitophagy. Raw data are available from the GDC and GEO under the accessions listed above.

## Declarations

### Ethics approval and consent to participate

Not applicable. All datasets used in this study were obtained from public repositories, and no new human or animal samples were collected.

### Consent for publication

Not applicable.

### Funding

The authors received no specific funding for this work.

### Declaration of competing interest

The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

### CRediT authorship contribution statement

**Shaomin Guo:** Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Software, Validation, Visualization, Writing - original draft. **Zeen Ren:** Conceptualization, Project administration, Resources, Supervision, Writing - review & editing.

### Acknowledgements

Not applicable.

## Figure legends

**Figure 1. Study design and analytical framework.** Bulk, single-cell, and spatial transcriptomic layers used in this study. Bulk cohorts were used as a negative-control layer. Single-cell datasets were used to compare malignant and myeloid states. Spatial transcriptomics was used to examine co-localization of L/M programs with bridge axes and myeloid neighborhoods.

**Figure 2. Bulk multi-cohort evaluation of lactylation and mitophagy programs.** Forest plots show odds ratios per standard deviation for L, M, and LMC scores in external cohorts. The lactylation program was nominally associated in two cohorts, whereas M and LMC did not replicate. Score distributions are shown by event status.

**Figure 3. Cell-type-associated L-M coupling in single-cell osteosarcoma.** Cell-type composition and L-M Spearman correlations across five samples. Malignant/osteoblastic cells show stronger L-M coupling than myeloid cells in datasets with adequate myeloid representation.

**Figure 4. L/M-high malignant states and bridge axes.** Heatmaps show Cliff's delta for HK-PRKN, SIRT1-ATG, HDAC6-SQSTM1, and HIF1A-BNIP3 in L-high versus L-low and M-high versus M-low malignant cells. Results are shown for upper and lower quartile definitions, with threshold sensitivity summarized in Supplementary Table S1.

**Figure 5. Spatial validation of L/M and bridge-axis co-localization.** Spatial maps show L, M, bridge-axis, and myeloid scores in GSE299025 PatientA and PatientB. Moran's I summaries and spot-level correlations are shown. Neighborhood panels show L/M-high spots adjacent to M2/TAM-high spots under a label-permutation model.

**Figure 6. Integrated model and target-level drug hypotheses.** The model summarizes a bulk-negative, state-associated, and spatially structured result. L/M-high malignant states co-activate HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 and are adjacent to M2/TAM-rich neighborhoods. The drug-priority panel shows target-level hypotheses rather than validated compounds.

# References

[1] Emma C. Bull, Archana Singh, Amy M. Harden, Kirsty Soanes, Hala Habash, Lisa Toracchio, et al. Targeting metastasis in paediatric bone sarcomas. Mol Cancer. 2025;24(1):153. https://doi.org/10.1186/s12943-025-02365-z

[2] Sigbjørn Smeland, Stefan S. Bielack, Jeremy Whelan, Mark Bernstein, Pancras Hogendoorn, Mark D. Krailo, et al. Survival and prognosis with osteosarcoma: outcomes in more than 2000 patients in the EURAMOS-1 (European and American Osteosarcoma Study) cohort. European Journal of Cancer. 2019;109:36-50. https://doi.org/10.1016/j.ejca.2018.11.027

[3] Isabelle Corre, Franck Verrecchia, Vincent Crenn, Francoise Redini, and Valérie Trichet. The Osteosarcoma Microenvironment: A Complex but Targetable Ecosystem. Cells. 2020;9(4):976. https://doi.org/10.3390/cells9040976

[4] Chenglong Chen, Lu Xie, Tingting Ren, Yi Huang, Jie Xu, and Wei Guo. Immunotherapy for osteosarcoma: Fundamental mechanism, rationale, and recent breakthroughs. Cancer Letters. 2021;500:1-10. https://doi.org/10.1016/j.canlet.2020.12.024

[5] Paul S. Meltzer, and Lee J. Helman. New Horizons in the Treatment of Osteosarcoma. N Engl J Med. 2021;385(22):2066-2076. https://doi.org/10.1056/nejmra2103423

[6] Changwu Wu, Jun Tan, Hong Shen, Chao Deng, Christian Kleber, Georg Osterhoff, et al. Exploring the relationship between metabolism and immune microenvironment in osteosarcoma based on metabolic pathways. J Biomed Sci. 2024;31(1):4. https://doi.org/10.1186/s12929-024-00999-7

[7] Shengnan Yu, and Xudong Yao. Advances on immunotherapy for osteosarcoma. Mol Cancer. 2024;23(1):192. https://doi.org/10.1186/s12943-024-02105-9

[8] Shuangshuang Sun, Zhe Xu, Liying He, Yihui Shen, Yuqing Yan, Xubing Lv, et al. Metabolic regulation of cytoskeleton functions by HDAC6-catalyzed α-tubulin lactylation. Nat Commun. 2024;15(1):8377. https://doi.org/10.1038/s41467-024-52729-0

[9] Heyu Li, Chao Liu, Ran Li, Lili Zhou, Yu Ran, Qiqing Yang, et al. AARS1 and AARS2 sense l-lactate to regulate cGAS as global lysine lactyltransferases. Nature. 2024;634(8036):1229-1237. https://doi.org/10.1038/s41586-024-07992-y

[10] Enwei Wei, Donglei Ji, Yanjie Jia, Ze Sun, Chunfeng Gao, Caroline Zeng, et al. BRD9 recognizes lactate-induced H3K18 lactylation to drive oncogenic chromatin remodeling in hepatocellular carcinoma. Cell Death Differ. 2026;33(10):1946-1959. https://doi.org/10.1038/s41418-026-01698-6

[11] Runhua Du, Yanmei Gao, Cong Yan, Xuelian Ren, Shankang Qi, Guobin Liu, et al. Sirtuin 1/sirtuin 3 are robust lysine delactylases and sirtuin 1-mediated delactylation regulates glycolysis. iScience. 2024;27(10):110911. https://doi.org/10.1016/j.isci.2024.110911

[12] Carlos Moreno-Yruela, Di Zhang, Wei Wei, Michael Bæk, Wenchao Liu, Jinjun Gao, et al. Class I histone deacetylases (HDAC1–3) are histone lysine delactylases. Sci. Adv. 2022;8(3):eabi6696. https://doi.org/10.1126/sciadv.abi6696

[13] Guijin Zhai, Ziping Niu, Zixin Jiang, Fei Zhao, Siyu Wang, Chen Chen, et al. DPF2 reads histone lactylation to drive transcription and tumorigenesis. Proc. Natl. Acad. Sci. U.S.A. 2024;121(50):e2421496121. https://doi.org/10.1073/pnas.2421496121

[14] Hao Wang, Zhongxuan Wu, Rui Yang, Shenglin Xu, Shunjie Yao, Ziheng Wu, et al. DHX9 transcriptional upregulation and lactylation at K1024 fuels a glycolysis–histone lactylation loop in osteosarcoma. J Transl Med. 2026;24(1):1175. https://doi.org/10.1186/s12967-026-08493-4

[15] Zhaochen Tong, Yi Peng, Dong Wang, Lingpu Zhang, Sijie Wen, Zixin Li, et al. Bone‐Targeted Nanoparticles Enable Metabolic Reprogramming via cGAS Lactylation Suppression to Restore Chemosensitivity and Antitumor Immunity in Osteosarcoma. Advanced Materials. 2026;38(30):e73147. https://doi.org/10.1002/adma.73147

[16] Shidong Hu, Ling Wu, Jianhua Wang, and Fengsheng Dai. Lactylation-driven metabolic reprogramming promotes osteosarcoma malignancy via HDGF-mediated proliferation and immune modulation. Front. Immunol. 2026;17:1836254. https://doi.org/10.3389/fimmu.2026.1836254

[17] Chunfeng Fu, Jiaqin Wu, Shuwan Hou, Minfu Liu, Shunshun Wang, Qianqian Du, et al. Ginkgolide A Suppresses Osteosarcoma Proliferation and Activates the Apoptotic Pathway by Targeting the KAT2A-H3K18la Lactylation Axis. ACAMC. 2026;26. https://doi.org/10.2174/0118715206443791260209074742

[18] Zhou Xie, Xiao Qu, Jun Zhang, Yanran Huang, Zhao Runhan, Dagang Tang, et al. Integrative single-cell and bulk RNA-seq analysis identifies lactylation-related signature in osteosarcoma. Funct Integr Genomics. 2025;25(1):60. https://doi.org/10.1007/s10142-025-01559-4

[19] Xue Zhang, Mingyue Guan, Yuanyuan Wang, Chenglong Ding, Xingchen Yu, Jiale Shi, et al. PFKP promotes oncogenesis in osteosarcoma through PI3K/HIF-1α pathway-mediated H3K18la modification. Cellular Signalling. 2026;147:112733. https://doi.org/10.1016/j.cellsig.2026.112733

[20] Yan Huang, Tao Feng, Bo Yang, Qian Yu, Yisheng Wang, Liping Feng, et al. Single-cell multi-omics reveals NUF2 as a potential biomarker associated with the high-lactylation malignant state in osteosarcoma. Int J Biol Markers. 2026;41:03936155261465683. https://doi.org/10.1177/03936155261465683

[21] Natalie M. Niemi, and Jonathan R. Friedman. Coordinating BNIP3/NIX-mediated mitophagy in space and time. Biochemical Society Transactions. 2024;52(5):1969-1979. https://doi.org/10.1042/bst20221364

[22] Shuai Wang, Zhantao Deng, Yuanchen Ma, Jiewen Jin, Fangjie Qi, Shuxian Li, et al. The Role of Autophagy and Mitophagy in Bone Metabolic Disorders. Int. J. Biol. Sci. 2020;16(14):2675-2691. https://doi.org/10.7150/ijbs.46627

[23] Ming Chen, Ziheng Chen, Yueying Wang, Zheng Tan, Chongzhuo Zhu, Yanjun Li, et al. Mitophagy receptor FUNDC1 regulates mitochondrial dynamics and mitophagy. Autophagy. 2016;12(4):689-702. https://doi.org/10.1080/15548627.2016.1151580

[24] Chaojun Yan, Longlong Gong, Li Chen, Meng Xu, Hussein Abou-Hamdan, Mingliang Tang, et al. PHB2 (prohibitin 2) promotes PINK1-PRKN/Parkin-dependent mitophagy by the PARL-PGAM5-PINK1 axis. Autophagy. 2020;16(3):419-434. https://doi.org/10.1080/15548627.2019.1628520

[25] Konstantinos Palikaras, Eirini Lionaki, and Nektarios Tavernarakis. Mechanisms of mitophagy in cellular homeostasis, physiology and pathology. Nat Cell Biol. 2018;20(9):1013-1022. https://doi.org/10.1038/s41556-018-0176-2

[26] Sven Geisler, Kira M. Holmström, Diana Skujat, Fabienne C. Fiesel, Oliver C. Rothfuss, Philipp J. Kahle, et al. PINK1/Parkin-mediated mitophagy is dependent on VDAC1 and p62/SQSTM1. Nat Cell Biol. 2010;12(2):119-131. https://doi.org/10.1038/ncb2012

[27] Caterina Vianello, Veronica Cocetta, Daniela Catanzaro, Gerald W Dorn, Angelo De Milito, Flavio Rizzolio, et al. Cisplatin resistance can be curtailed by blunting Bnip3-mediated mitochondrial autophagy. Cell Death Dis. 2022;13(4):398. https://doi.org/10.1038/s41419-022-04741-9

[28] Lingyan Chen, Dejian Chen, Yiming Pan, Yimei Mo, Biyu Lai, Huiguang Chen, et al. Inhibition of mitochondrial OMA1 ameliorates osteosarcoma tumorigenesis. Cell Death Dis. 2024;15(11):786. https://doi.org/10.1038/s41419-024-07127-1

[29] Zhiwei Tao, Pingan Zou, Zhengxu Yang, Tao Xiong, Zhi Deng, and Qinchan Chen. Targeting TIMM23 to overcome osteosarcoma chemoresistance. Cell Death Dis. 2025;16(1):856. https://doi.org/10.1038/s41419-025-08106-w

[30] Lingyuan Zeng, Shuwei Li, Kaidong Wu, Xiaoyu Bai, and Long Zhang. Anti-tumor effects of Guggulsterone in osteosarcoma: Role of SIRT3-mediated PINK1-Parkin mitophagy activation. Phytomedicine. 2026;153:157860. https://doi.org/10.1016/j.phymed.2026.157860

[31] Xiuxin Han, Yiqin Li, Yongheng Liu, Feng Wang, Tingfang Li, Qingchen Zhang, et al. Integrated multi-omics reveals GABARAP-mediated mitophagy and pyruvate metabolism as key drivers of osteosarcoma progression. Front. Immunol. 2025;16:1680554. https://doi.org/10.3389/fimmu.2025.1680554

[32] Wei Shi, Lei Zhang, Liying Mei, Chengqi Zhang, Lei Liu, Nan Zhao, et al. Single-cell mitophagy patterns dictate intercellular crosstalk in the tumor microenvironment to promote osteosarcoma progression. Transl Cancer Res. 2026;15(6):499-499. https://doi.org/10.21037/tcr-2026-0735

[33] Weiji Weng, Zhenghui He, Zixuan Ma, Jialin Huang, Yuhan Han, Qiyuan Feng, et al. Tufm lactylation regulates neuronal apoptosis by modulating mitophagy in traumatic brain injury. Cell Death Differ. 2025;32(3):530-545. https://doi.org/10.1038/s41418-024-01408-0

[34] Jiaying Li, Xiaoxiao Shi, Jiatong Xu, Kaiyue Wang, Fangxing Hou, Xiaodong Luan, et al. Aldehyde Dehydrogenase 2 Lactylation Aggravates Mitochondrial Dysfunction by Disrupting PHB2 Mediated Mitophagy in Acute Kidney Injury. Advanced Science. 2025;12(8):2411943. https://doi.org/10.1002/advs.202411943

[35] Han‐jun Qin, Si‐ying He, Ting‐hui Xiao, Da‐mao Dai, Xin‐jia Hu, and Nan Jiang. Lactylation Reprogramming in the Bone Infection Microenvironment Identifies PGK1 K361 as a Potential Therapeutic Target for Osteogenic Dysfunction. Advanced Science. 2026;13(19):e23583. https://doi.org/10.1002/advs.202523583

[36] Xiaolin Deng, Yuan Huang, Jinge Zhang, Yuwen Chen, Feifan Jiang, Zicai Zhang, et al. Histone lactylation regulates PRKN-Mediated mitophagy to promote M2 Macrophage polarization in bladder cancer. International Immunopharmacology. 2025;148:114119. https://doi.org/10.1016/j.intimp.2025.114119

[37] Henghui Zhang, Dongqing Li, Mingqiang Su, Zaosong Zheng, Wei Chen, Haiyong Chen, et al. Lactate-driven H3K18 lactylation promotes cisplatin resistance in bladder cancer via HNRNPF-Parkin mediated mitophagy. Drug Resistance Updates. 2026;88:101435. https://doi.org/10.1016/j.drup.2026.101435

[38] Sihan Li, Qian Jiang, Quanji Wang, Xingbo Li, Zihan Wang, Linpeng Xu, et al. p300-mediated histone H3K18 lactylation promotes mitochondrial ROS accumulation via mitophagy inhibition to potentiate dopamine agonists efficacy in prolactinomas. Redox Biology. 2026;91:104077. https://doi.org/10.1016/j.redox.2026.104077

[39] Yuman He, Zhongzhong Ji, Yiming Gong, Liancheng Fan, Penghui Xu, Xinyu Chen, et al. Numb/Parkin-directed mitochondrial fitness governs cancer cell fate via metabolic regulation of histone lactylation. Cell Reports. 2023;42(2):112033. https://doi.org/10.1016/j.celrep.2023.112033

[40] Zhangjie Wang, Chaoyi Li, Ruiqiu Zhu, Minghao Duan, Zhenyu Kuang, Xin Li, et al. Targeting USP7 lactylation suppresses NSCLC tumorigenesis by promoting PINK1 ubiquitination and degradation. Autophagy. 2026:1-19. https://doi.org/10.1080/15548627.2026.2728617

[41] Yizhuo Wang, Xin Wang, Yang Liu, Jiayuan Xu, Jiyuan Zhu, Yufu Zheng, et al. A novel hypoxia- and lactate metabolism-related prognostic signature to characterize the immune landscape and predict immunotherapy response in osteosarcoma. Front. Immunol. 2024;15:1467052. https://doi.org/10.3389/fimmu.2024.1467052

[42] Yan Zhou, Dong Yang, Qingcheng Yang, Xiaobin Lv, Wentao Huang, Zhenhua Zhou, et al. Single-cell RNA landscape of intratumoral heterogeneity and immunosuppressive microenvironment in advanced osteosarcoma. Nat Commun. 2020;11(1):6322. https://doi.org/10.1038/s41467-020-20059-6

[43] Jihao Tu, Duo Wang, XiaoTian Zheng, and Bin Liu. Single-cell RNA datasets and bulk RNA datasets analysis demonstrated C1Q+ tumor-associated macrophage as a major and antitumor immune cell population in osteosarcoma. Front. Immunol. 2023;14:911368. https://doi.org/10.3389/fimmu.2023.911368

[44] Jiatong Li, Yang Bai, He Zhang, Ting Chen, and Guanning Shang. Single-cell RNA sequencing reveals the communications between tumor microenvironment components and tumor metastasis in osteosarcoma. Front. Immunol. 2024;15:1445555. https://doi.org/10.3389/fimmu.2024.1445555

[45] Yan Liao, Junkai Chen, Hao Yao, Ting Zheng, Jian Tu, Weidong Chen, et al. Single-cell profiling of SLC family transporters: uncovering the role of SLC7A1 in osteosarcoma. J Transl Med. 2025;23(1):103. https://doi.org/10.1186/s12967-025-06086-1

[46] Yujing Huang, Dongyan Cao, Manxue Zhang, Yue Yang, Gengming Niu, Lina Tang, et al. Exploring the impact of PDGFD in osteosarcoma metastasis through single-cell sequencing analysis. Cell Oncol. 2024;47(5):1715-1733. https://doi.org/10.1007/s13402-024-00949-3

[47] Yun Liu, Mingwei He, Haijun Tang, Tianyu Xie, Yunhua Lin, Shangyu Liu, et al. Single-cell and spatial transcriptomics reveal metastasis mechanism and microenvironment remodeling of lymph node in osteosarcoma. BMC Med. 2024;22(1):200. https://doi.org/10.1186/s12916-024-03319-w

[48] Aaron Michael Taylor, Jianting Sheng, Patrick Kwok Shing Ng, Jeffrey M. Harder, Parveen Kumar, Ju Young Ahn, et al. Immunosuppressive Tumor Microenvironment of Osteosarcoma. Cancers. 2025;17(13):2117. https://doi.org/10.3390/cancers17132117

[49] Consolato M. Sergi. Targeting the ‘garbage-bin’ to fight cancer: HDAC6 inhibitor WT161 has an anti-tumor effect on osteosarcoma and synergistically interacts with 5-FU. Bioscience Reports. 2021;41(8):BSR20210952. https://doi.org/10.1042/bsr20210952

[50] Hongchun Dai, Guangming Yi, Dong Jiang, Yanmei Min, and Zongwei Li. Circ_0000376 regulates miR-577/HK2/LDHA signaling pathway to promote the growth, invasion and glycolysis of osteosarcoma. J Orthop Surg Res. 2024;19(1):67. https://doi.org/10.1186/s13018-023-04520-y

[51] Zhong Lei, Huijie Duan, Tengfei Zhao, Yuxiang Zhang, Guoqi Li, Jiahong Meng, et al. PARK2 inhibits osteosarcoma cell growth through the JAK2/STAT3/VEGF signaling pathway. Cell Death Dis. 2018;9(3):375. https://doi.org/10.1038/s41419-018-0401-8

[52] Qiuming Zou, Xiaofeng Zhou, Jianqin Lai, Haixia Zhou, Jinxuan Su, Zhijing Zhang, et al. Targeting p62 by sulforaphane promotes autolysosomal degradation of SLC7A11, inducing ferroptosis for osteosarcoma treatment. Redox Biology. 2025;79:103460. https://doi.org/10.1016/j.redox.2024.103460

[53] Wanshun Liu, Lei Li, Xiaoming Bai, Mengxue Zhang, Wei Lv, Yongbin Ma, et al. Osteosarcoma Cell‐Derived Migrasomes Promote Macrophage M2 Polarization to Aggravate Osteosarcoma Proliferation and Metastasis. Advanced Science. 2025;12(17):2409870. https://doi.org/10.1002/advs.202409870

[54] Jinti Lin, Ankai Xu, Jiakang Jin, Man Zhang, Jianan Lou, Chao Qian, et al. MerTK-mediated efferocytosis promotes immune tolerance and tumor progression in osteosarcoma through enhancing M2 polarization and PD-L1 expression. OncoImmunology. 2022;11(1):2024941. https://doi.org/10.1080/2162402x.2021.2024941

[55] Jason Eigenbrood, Nathan Wong, Paul Mallory, Janice S. Pereira, Demond Williams, Douglass W. Morris-II, et al. Spatial Profiling Identifies Regionally Distinct Microenvironments and Targetable Immunosuppressive Mechanisms in Pediatric Osteosarcoma Pulmonary Metastases. Cancer Research. 2025;85(12):2320-2337. https://doi.org/10.1158/0008-5472.can-24-3723


