# Weak-text reference audit (13 papers)

## Review method
Each of the 13 PDFs was re-opened with the bounded-memory PDF reader and checked against its Crossref DOI record and its extracted full-text evidence sentences. The review focused on three questions: (1) is the citation identity correct; (2) does the paper actually support the claim assigned to it; and (3) should it remain in the 55-reference final set.

## Results
| Draft no. | First author (year) | Verification | Claim use | Decision |
|---:|---|---|---|---|
| 4 | Meltzer (2021) | Identity verified; first-page and conclusion text recovered | Osteosarcoma treatment stasis and clinical background | Keep |
| 6 | Sun (2024) | Identity verified; HDAC6-catalyzed alpha-tubulin lactylation supported | General lactylation machinery and HDAC6 writer function | Keep |
| 7 | Li (2024) | Identity verified; AARS1/AARS2 lactyltransferase function supported | General lactylation machinery | Keep |
| 19 | Wu (2026) | Identity verified; review only | Metabolic drug-resistance context | Reserve; not in final 55 |
| 24 | Palikaras (2018) | Identity verified; mitophagy mechanism review | General mitophagy background | Keep |
| 25 | Geisler (2010) | Identity verified; PINK1/Parkin, VDAC1 and p62/SQSTM1 supported | PINK1-PRKN-SQSTM1 bridge-axis background | Keep |
| 30 | Han (2025) | Identity verified; GABARAP mitophagy and pyruvate-lactate rewiring supported | Osteosarcoma mitophagy context | Keep |
| 33 | Li (2025) | Identity verified; ALDH2 lactylation, PHB2 degradation and mitophagy inhibition supported | Direct lactylation-mitophagy intersection | Keep |
| 40 | Zhou (2020) | Identity verified; osteosarcoma single-cell atlas supported | Single-cell osteosarcoma context and GSE152048 source | Keep |
| 42 | Tu (2023) | Identity verified; C1Q+ macrophage population supported | Myeloid/macrophage microenvironment context | Keep |
| 49 | Liu (2025) | Identity verified; migrasome-driven M2 polarization supported | M2/TAM neighborhood interpretation | Keep |
| 50 | Wang (2024) | Identity verified; hypoxia-lactate signature and M2 polarization supported | Prior lactylation/hypoxia signature context | Keep |
| 55 | Sergi (2021) | Identity verified; HDAC6 inhibitor WT161 in osteosarcoma supported | HDAC6-SQSTM1 drug hypothesis | Keep |

## Conclusion
- 12 of the 13 remain in the 55-reference final set; Wu (2026) is retained as a reserve reference.
- No identity mismatch, retraction notice, or contradictory evidence was found in the reviewed text.
- The remaining weak-text limitation is PDF heading-order rather than evidence content. No citation should be used beyond the specific role listed above.
