# JBO reference audit

## What was done

- Input PDFs: 92 files across `outputs/group1` through `outputs/group9`; original folders were not modified.
- Candidate set: 58 references selected after evidence-group screening.
- Metadata verification: DOI records checked against Crossref; the DPF2/H3K14la PNAS record was repaired from the PDF first page (`10.1073/pnas.2421496121`).
- Deep reading: 58/58 PDFs were processed sequentially with a bounded-memory workflow. The deck contains abstracts, conclusions, and candidate evidence sentences for every paper.
- Renamed library: `outputs/refs/` contains 58 full PDF copies named `Title_FirstAuthor_Year.pdf`.
- Integrity: 58/58 renamed copies passed SHA256 comparison with their source PDFs.
- Final selection: 55 references, consistent with the JBO 30-60 reference limit. Three candidate papers were left in the library but not selected.

## Files for the next stage

- `outputs/refs/reference_registry_final.csv`: full metadata and source-to-final mapping for the 58 renamed PDFs.
- `work/JBO_refs_review/deep_reading_cards_v1/`: 58 individual evidence cards.
- `work/JBO_refs_review/deep_reading_workbook_v1.md`: combined reading workbook.
- `outputs/JBO_submission/JBO_references_final.md`: 55 numbered references with DOI links.
- `outputs/JBO_submission/JBO_claim_citation_matrix.csv`: claim-to-reference map.
- `outputs/JBO_submission/JBO_manuscript_with_refs.md`: cited manuscript draft plus reference list.

## Manual checks still required

- The 13 cards marked `weak_text` were still readable for metadata and key evidence extraction; their section headings are irregular. Their citation use should be spot-checked during final proofing.
- The final manuscript should be rebuilt from the cited draft, the exploratory bulk DE replaced with DESeq2 or edgeR, and author/CRediT/funding statements completed.
- Figure files still need the final JBO size and collision audit before submission.

## Excluded from the 55-reference final set

- Qun Wu (2026), metabolic reprogramming-related drug resistance review.
- Consolato Sergi (2019), insulin/IGF-1R/SIRT1/FOXO review.
- Wenqing Liang (2024), bone-scaffold localized drug-delivery review.

These three remain available in `outputs/refs/` as reserve references.

## Final status (2026-10-03)

- Weak-text review completed for all 13 flagged papers.
- Final references were renumbered by first citation appearance; all 55 numbers are sequential and complete.
- Final Word files: `JBO_manuscript_final.docx` and `JBO_title_page_final.docx`.
- Bulk DE was replaced with PyDESeq2 on raw TARGET-OS counts; 464 genes at FDR < 0.05.
- A portrait 531 x 1328 graphical abstract and a safe-padded Figure 5 copy were generated.

