# JBO Reference Search and Download Plan

**Target**: download 60-65 PDFs; select 45-55 for the final manuscript. JBO permits 30-60 references, so a pool of 60-65 allows replacement of weak or redundant citations.

## Group 1. Osteosarcoma epidemiology, prognosis, and treatment
- Suggested download: **5-6 PDFs**
- PubMed search:
`("osteosarcoma"[MeSH Terms] OR osteosarcoma[Title/Abstract]) AND (epidemiology[Title/Abstract] OR prognosis[Title/Abstract] OR survival[Title/Abstract] OR metastasis[Title/Abstract] OR chemotherapy[Title/Abstract] OR treatment[Title/Abstract])`
- Purpose: introduction, clinical burden, metastatic outcome, and treatment context.

## Group 2. Lactylation writers, erasers, readers, and general biology
- Suggested download: **8 PDFs**
- PubMed search:
`(lactylation[Title/Abstract] OR lactyl*[Title/Abstract]) AND (EP300[Title/Abstract] OR CREBBP[Title/Abstract] OR HDAC[Title/Abstract] OR SIRT[Title/Abstract] OR AARS1[Title/Abstract] OR AARS2[Title/Abstract] OR BRD9[Title/Abstract] OR DPF2[Title/Abstract] OR writer[Title/Abstract] OR eraser[Title/Abstract] OR reader[Title/Abstract])`
- Seed PMIDs: 39322678, 35044827, 39351192, 41792243, 39636855.

## Group 3. Lactylation in osteosarcoma and bone tumors
- Suggested download: **8 PDFs**
- PubMed search:
`(lactylation[Title/Abstract] OR lactyl*[Title/Abstract]) AND (osteosarcoma[Title/Abstract] OR sarcoma[Title/Abstract] OR "bone tumor"[Title/Abstract] OR "bone tumour"[Title/Abstract])`
- Seed PMIDs: 40072643, 42363192, 42425209, 42021558, 42605718, 41940424, 39584587, 40126678.
- Purpose: document the crowded field and justify our cell-state-specific reframing.

## Group 4. Mitophagy and mitochondrial quality control
- Suggested download: **8 PDFs**
- PubMed search:
`(mitophagy[Title/Abstract] OR mitophag*[Title/Abstract]) AND (PINK1[Title/Abstract] OR PRKN[Title/Abstract] OR Parkin[Title/Abstract] OR BNIP3[Title/Abstract] OR FUNDC1[Title/Abstract] OR SQSTM1[Title/Abstract] OR MAP1LC3B[Title/Abstract] OR ULK1[Title/Abstract] OR ATG5[Title/Abstract] OR ATG7[Title/Abstract])`
- Purpose: mechanism background and bridge-axis rationale.

## Group 5. Mitophagy in osteosarcoma
- Suggested download: **7-8 PDFs**
- PubMed search:
`(mitophagy[Title/Abstract] OR mitophag*[Title/Abstract]) AND (osteosarcoma[Title/Abstract] OR sarcoma[Title/Abstract] OR "bone tumor"[Title/Abstract])`
- Seed PMIDs: 35459212, 38932521, 41650525, 41346635, 42445385, 41285805, 39696352.
- Purpose: establish prior OS mitophagy biology and distinguish our bridge-axis contribution.

## Group 6. Direct lactylation-mitophagy crosstalk mechanisms
- Suggested download: **10 PDFs**
- PubMed search:
`(lactylation[Title/Abstract] OR lactyl*[Title/Abstract]) AND (mitophagy[Title/Abstract] OR mitophag*[Title/Abstract])`
- Additional searches:
`PINK1 AND lactylation`
`PRKN AND lactylation`
`SIRT3 AND lactylation AND mitophagy`
`H3K18la AND mitophagy`
- Seed PMIDs: 39496783, 39854875, 42308687, 41740506, 39737891, 36724072, 42802902, 41603270.
- Purpose: core rationale for the bridge-axis concept.

## Group 7. Osteosarcoma single-cell and spatial transcriptomics
- Suggested download: **7 PDFs**
- PubMed search:
`(osteosarcoma[Title/Abstract] OR "bone sarcoma"[Title/Abstract]) AND ("single cell"[Title/Abstract] OR scRNA[Title/Abstract] OR "single-cell RNA"[Title/Abstract] OR "spatial transcriptomics"[Title/Abstract] OR Visium[Title/Abstract])`
- Dataset anchors: GSE152048 (PMID 33303760), GSE162454, GSE318840, GSE299023/GSE299025 (PMID 40647416).
- Purpose: methodological context and comparison with previous single-cell findings.

## Group 8. Osteosarcoma immune and metabolic microenvironment
- Suggested download: **6 PDFs**
- PubMed search:
`(osteosarcoma[Title/Abstract] OR "bone sarcoma"[Title/Abstract]) AND (macrophage[Title/Abstract] OR "tumor microenvironment"[Title/Abstract] OR "immune microenvironment"[Title/Abstract] OR M2[Title/Abstract] OR glycolysis[Title/Abstract] OR hypoxia[Title/Abstract])`
- Purpose: interpret M2/TAM neighborhood enrichment and metabolic coupling.

## Group 9. Candidate bridge-axis drugs and repurposing
- Suggested download: **6 PDFs**
- PubMed search:
`(osteosarcoma[Title/Abstract] OR sarcoma[Title/Abstract]) AND (HDAC6[Title/Abstract] OR SQSTM1[Title/Abstract] OR HK2[Title/Abstract] OR PRKN[Title/Abstract] OR SIRT1[Title/Abstract] OR ATG7[Title/Abstract]) AND (inhibitor[Title/Abstract] OR drug[Title/Abstract] OR repurposing[Title/Abstract] OR therapy[Title/Abstract])`
- Additional searches:
`ricolinostat AND osteosarcoma`
`tubastatin A AND osteosarcoma`
`lonidamine AND osteosarcoma`
`urolithin A AND osteosarcoma`
- Purpose: support the drug-prioritization discussion without making efficacy claims.

## Download priority
1. Groups 6, 2, and 5 are highest priority.
2. Groups 3 and 7 are needed to position the paper against prior literature and justify the datasets.
3. Groups 1, 8, and 9 complete the Introduction, Discussion, and translational interpretation.

## PDF naming convention
`GroupNumber_FirstAuthor_Year_PMID.pdf`

