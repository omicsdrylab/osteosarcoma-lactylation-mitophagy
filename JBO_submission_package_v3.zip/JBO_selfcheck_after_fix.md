# Self-check after correction

Date: 2026-10-03

## Completed corrections

- Title changed from `cell-state-specific` to `cell-state-associated`.
- Figure 1-6 callouts inserted into Results.
- Figure legends added to the manuscript.
- Six separate figure files packaged as `Figure_1` to `Figure_6`.
- The C1Q+ macrophage citation was removed from the M2/TAM support sentence.
- The hypoxia/lactate-metabolism signature reference is now described as such.
- Cell-level P values were removed from biological inference.
- The spatial label-permutation result is now described as descriptive.
- Threshold sensitivity at 20th, 25th, 30th and 33rd percentiles was completed.
- DESeq2 was refit with sex and age. FDR<0.05 is 431 and nominal P<0.05 is 4,033.
- Framework-style and defensive language was reduced in the abstract and discussion.

## Current manuscript metrics

- Main text: 2256 words, excluding abstract, legends, references and declarations.
- References: 55, all cited and numbered by first appearance.
- Figures: 6 main figures plus one graphical abstract.
- Language audit: mean sentence length 16.1 words; 5 of 173 sentences exceed 30 words.
- AI-like term counts after revision: `reproduc*` 1, `cell-state-specific` 0, `not only` 0, `instead of` 0.

## Remaining limitations

- Cell-level correlations are now descriptive. A future revision could add pseudobulk or mixed-model inference.
- Spatial neighborhood enrichment is descriptive because the permutation does not preserve spatial autocorrelation.
- The spatial analysis uses two patients, so no population-level inference is claimed.
- No wet-lab validation is included; all mechanistic statements are bounded as hypotheses.
- Funding and competing-interest statements were confirmed by the author.
- The public code repository URL has been inserted: https://github.com/omicsdrylab/osteosarcoma-lactylation-mitophagy.
- The author confirmed the final Word pagination and Figure 5 safe copy.


- Removed all A1/A2/week/gate project labels from Figures 1-3 and regenerated both PNG and PDF versions.
