# Title Page

## Title
Cell-state-associated lactylation-mitophagy coupling and bridge-axis activation in osteosarcoma: a bulk, single-cell, and spatial transcriptomic study

## Authors
Shaomin Guo^1, Zeen Ren^2,*

## Affiliations
1. Changzhi Medical College, No. 161 Jiefang East Street, Luzhou District, Changzhi, Shanxi, China
2. Changzhi Second People's Hospital, No. 83 Heping West Street, Luzhou District, Changzhi, Shanxi, China

## Corresponding author
Zeen Ren, MD
Chief Physician, Changzhi Second People's Hospital, No. 83 Heping West Street, Luzhou District, Changzhi, Shanxi, China
Email: rln8999@163.com
Phone: +86 130 0807 8999

## First author
Shaomin Guo, MM candidate
Changzhi Medical College, No. 161 Jiefang East Street, Luzhou District, Changzhi, Shanxi, China
Email: 1457239796@qq.com
Phone: +86 134 2814 8059

## Author details
- **Shaomin Guo**, MM candidate, Changzhi Medical College, Changzhi, Shanxi, China; male; born 2002; email 1457239796@qq.com; mobile +86 134 2814 8059.
- **Zeen Ren**, MD, Chief Physician, Changzhi Second People's Hospital, Changzhi, Shanxi, China; male; born 1976; email rln8999@163.com; mobile +86 130 0807 8999. Corresponding author.

## Keywords
osteosarcoma; lactylation; mitophagy; single-cell transcriptomics; spatial transcriptomics; tumor microenvironment

## CRediT author statement
**Shaomin Guo:** Conceptualization, Data curation, Formal analysis, Investigation, Methodology, Software, Validation, Visualization, Writing - original draft. **Zeen Ren:** Conceptualization, Project administration, Resources, Supervision, Writing - review & editing.

## Funding
The authors received no specific funding for this work.

## Competing interests
The authors declare no competing interests.

