# Highlights

- Global bulk lactylation-mitophagy coupling was not reproducible.
- Malignant cells show stronger L-M coupling than myeloid cells.
- L/M-high malignant states activate HK-PRKN, SIRT1-ATG, HDAC6-SQSTM1.
- Spatial analysis confirms bridge-axis and M2/TAM co-localization.
- HDAC6-SQSTM1 and HK-PRKN are prioritized translational hypotheses.