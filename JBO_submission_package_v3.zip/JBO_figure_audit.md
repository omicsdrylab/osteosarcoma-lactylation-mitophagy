# JBO Figure Audit

## Main figures

| Figure | PNG pixels | Effective DPI | PDF points | Margin flag | Status |
|---|---:|---:|---:|---|---|
| Figure 1 | 3600 x 2100 | ~300 | 864.0 x 504.0 | No edge touch | Technical audit complete |
| Figure 2 | 2400 x 3800 | ~300 | 576.0 x 912.0 | No edge touch | Technical audit complete |
| Figure 3 | 2400 x 800 | ~300 | 576.0 x 192.0 | No edge touch | Technical audit complete |
| Figure 4 | 2400 x 800 | ~300 | 576.0 x 192.0 | No edge touch | Technical audit complete |
| Figure 5 | 2400 x 3427 | ~300 | 576.0 x 822.5 | Top margin 0.35% | Safe padded copy generated: `figures_final/Figure5_safe.png` and `.pdf`; visual check still recommended |
| Figure 6 | 2400 x 1866 | ~300 | 576.0 x 447.8 | No edge touch | Technical audit complete |

## Graphical abstract

- Final portrait file: 531 x 1328 px.
- TIFF: 1593 x 3984 px at 300 dpi.
- Landscape v1 retained as `JBO_graphical_abstract_landscape_backup.*`.
- Margins: left 3.01%, right 3.01%, top 2.03%, bottom 6.17%.

## Limits of this audit

The main figure PDFs contain raster panels rather than a vector text layer. Therefore, programmatic detection cannot reliably identify every text collision. Figure 5 is the only file with a tight top margin flag (12 px, 0.35%). It should be visually checked once in Word, PowerPoint, or a PDF viewer before submission. No figure was overwritten; all edits created separate audit or backup files.

## Safe Figure 5 copy

The original Figure 5 is preserved. A 2% white border was added around all sides to remove the tight top margin in the submission copy (Figure5_safe.png and Figure5_safe.pdf).


## Internal label cleanup (2026-10-04)

Figure 1: removed the 'A1+A2 integrated study design' title and A1/A2 labels inside the study-design boxes.
Figure 2: removed the 'A1 Week 3 Gate 1 forest plot' title.
Figure 3: removed the 'A2 Week 6B: cell-type L-M correlation' title.
PNG and PDF versions were regenerated after the cleanup.

- Figure 1 bottom summary box widened from 24% to 64% of the canvas to prevent text overflow.
