# Cover Letter - Journal of Bone Oncology

Dear Editor,

We submit our manuscript, "Cell-state-associated lactylation-mitophagy coupling and bridge-axis activation in osteosarcoma: a bulk, single-cell, and spatial transcriptomic study," for consideration as an Original Research Article.

Osteosarcoma is a primary bone tumour with limited therapeutic progress. Lactylation and mitophagy are separately implicated in osteosarcoma biology, but whether they form a coordinated program in patient tissue has not been resolved. We integrated bulk cohorts, single-cell transcriptomes, and spatial transcriptomes and found that global bulk coupling is not reproducible. Instead, the reproducible signal is a L/M-high malignant cell state that co-activates HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 and is spatially adjacent to immunosuppressive myeloid neighbourhoods.

This work fits the scope of Journal of Bone Oncology because it addresses primary bone tumour biology, the bone tumour microenvironment, candidate biomarkers, and bone-targeted therapeutic hypotheses. It also avoids the limitations of a generic lactylation prognostic signature by using bulk analysis as a negative-control layer and single-cell/spatial data as the mechanism-discovery layer. The bulk differential-expression analysis was performed with PyDESeq2 on raw TARGET-OS counts using a ~ condition + sex design and independent filtering.

All drug and causal claims are explicitly bounded as hypothesis-generating. The manuscript is original, not under consideration elsewhere, and all authors have approved the final version.

Sincerely,

Shaomin Guo, MM
First author, Changzhi Medical College
Email: 1457239796@qq.com
Phone: +86 134 2814 8059

Zeen Ren, MD
Corresponding author, Changzhi Second People's Hospital
Email: rln8999@163.com
Phone: +86 130 0807 8999

