# Final JBO package audit

- PASS: manuscript_final_exists
- PASS: title_page_final_exists
- PASS: references_final_exists
- PASS: deseq2_in_manuscript
- PASS: fdr431_in_manuscript
- PASS: figure_callouts_present
- PASS: figure_legends_present
- PASS: old_logcpm_absent
- PASS: all_55_citations
- PASS: first_author_email_in_title
- PASS: corresponding_email_in_title
- PASS: corresponding_name_in_title
- PASS: graphical_abstract_portrait
- PASS: safe_figure5_exists
- PASS: zip_has_manuscript_final
- PASS: zip_has_safe_figure5

- Distinct citation numbers: 55
- Reference entries in manuscript DOCX: 55
- Visual PDF render: not performed because the current Windows session has no interactive Word COM session and LibreOffice is unavailable.
