Cell-state-specific lactylation-mitophagy coupling and bridge-axis activation in osteosarcoma: a bulk, single-cell, and spatial transcriptomic study

## Abstract

**Background** Lactylation and mitophagy are separately implicated in osteosarcoma, but whether they form a coordinated patient-tissue program is unresolved.

**Methods** We integrated bulk cohorts (TARGET-OS, GSE21257, GSE39055, GSE33382, GSE16091), five single-cell samples (GSE152048, GSE162454, GSE318840), and two spatial transcriptomic samples (GSE299025). Curated lactylation and mitophagy programs were scored across scales. Bulk associations used logistic regression with a locked metastasis/relapse endpoint. Single-cell and spatial analyses resolved cell-type and spatial coupling patterns. Bridge axes were prioritized for drug hypothesis generation.

**Results** Bulk lactylation scores were nominally associated with metastasis/recurrence in two external cohorts after sex and age adjustment, but mitophagy and multiplicative coupling scores did not replicate. Single-cell analysis showed stronger L-M coupling in malignant/osteoblastic cells than in myeloid cells in datasets with adequate myeloid representation. Within malignant cells, L/M-high states consistently co-activated HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 across five samples from three datasets. Spatial analysis confirmed positive L/M autocorrelation and positive correlations with these bridge axes in two patients. L/M-high spots were enriched for neighboring M2/TAM-high spots (empirical P = 0.001 in both patients). HDAC6-SQSTM1 and HK-PRKN were the highest-priority translational hypotheses.

**Conclusions** Global bulk coupling was not reproducible, whereas a spatially structured L/M-high malignant state and specific bridge axes were reproducible. These findings define a cell-state-specific framework for osteosarcoma lactylation-mitophagy biology.

**Keywords:** osteosarcoma; lactylation; mitophagy; single-cell transcriptomics; spatial transcriptomics; tumor microenvironment

## Introduction

Osteosarcoma is the most common primary malignant bone tumor of children and adolescents. Its treatment has remained largely unchanged for decades, and metastatic or recurrent disease still carries a poor prognosis. Large-scale genomic studies have not identified recurrent disease-defining mutations that can be targeted in most patients, shifting interest toward metabolic and epigenetic programs that connect the tumor microenvironment with malignant-cell state.

Lactate is not only a glycolytic waste product but also a substrate for lysine lactylation, a post-translational modification that can regulate chromatin and non-histone proteins. In osteosarcoma, lactylation-related biology has been linked to metabolic reprogramming, immune modulation, chemotherapy response, and specific epigenetic axes such as DHX9, PFKP/HIF-1α/H3K18la, KAT2A/H3K18la, and cGAS lactylation. At the same time, mitophagy controls mitochondrial quality and influences osteosarcoma survival, metastasis, and cisplatin resistance through pathways including PINK1/PRKN, BNIP3, GABARAP, and TIMM23. Several non-osteosarcoma studies have directly connected the two processes, including Tufm lactylation in traumatic brain injury, PRKN-dependent mitophagy in macrophage polarization, lactate-driven H3K18la with HNRNPF-Parkin-mediated mitophagy in cisplatin resistance, and p300-mediated H3K18la with mitophagy inhibition in prolactinoma.

These observations suggest that lactylation and mitophagy may be biologically connected in osteosarcoma. However, most published osteosarcoma studies examine one program at a time, and transcriptome-based lactylation signatures have already produced many similar models. A previous lactylation-related osteosarcoma signature was retracted and another required a correction, illustrating the risk of treating a composite gene score as a validated mechanism. We therefore asked a different question: is there reproducible evidence of lactylation-mitophagy coupling across bulk, single-cell, and spatial scales, and if not, is the signal confined to specific cell states.

We integrated bulk osteosarcoma cohorts, single-cell transcriptomes, and spatial transcriptomes. Rather than assuming that global coupling must exist, we used bulk analysis as a negative-control layer and single-cell/spatial analysis as a cell-state discovery layer. We found that global LMC was not reproducible in bulk tissue, but L-M coupling and selected bridge axes were enriched in malignant/osteoblastic cell states and spatially co-localized with immunosuppressive myeloid neighborhoods. This reframing distinguishes a cell-state-specific mechanism from a generic lactylation signature and provides a reproducible basis for prioritizing HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 for further study.

## Results

### Bulk lactylation and mitophagy programs are not globally coupled

We first assembled a curated lactylation program and a mitophagy program from GO:0000423 and KEGG hsa04137. STRING analysis showed that the combined programs formed a highly interconnected network, but the two programs were modular rather than globally fused. Cross-program connectivity was enriched at medium-confidence STRING scores (score >= 400: 72 observed cross edges versus 39.3 expected, Z = 4.36, empirical P = 0.0002), but not at high-confidence scores (score >= 700: 15 observed versus 14.6 expected, Z = 0.10, P = 0.48). HDAC6 was shared between programs and was reported as a bridge node rather than included in the primary cross-group test.

We then evaluated bulk transcriptomes. In TARGET-OS, the primary endpoint was a composite metastasis or relapse/progression event (38 events, 50 non-events among 88 RNA-seq samples). External evaluation used GSE21257 (34 metastatic events and 19 non-events), GSE39055 (18 recurrences and 19 non-recurrences), and GSE33382 (34 metastases within five years and 19 non-metastases among 53 annotated biopsies).

The lactylation program showed a directionally consistent association with the primary endpoint in GSE21257 and GSE33382 (OR 1.95, 95% CI 1.04-3.67, P = 0.037; OR 1.97, 95% CI 1.04-3.72, P = 0.037). These associations persisted after adjustment for sex and age. However, the mitophagy program alone was not significant in any external cohort, and the multiplicative LMC score was not associated with the endpoint. Thus, bulk transcriptomes did not support a reproducible global lactylation-mitophagy coupling phenotype.

### Single-cell analysis reveals malignant-cell-enriched L-M coupling

Because bulk averaging can obscure cell-type-specific programs, we analyzed five osteosarcoma single-cell samples from GSE152048, GSE162454, and GSE318840. Marker-based annotation identified malignant/osteoblastic, myeloid, fibroblast, endothelial, T/NK, B/plasma, and chondrocyte compartments, with substantial variation in composition across samples.

Within each sample, we calculated L and M scores per cell and correlated them within cell types. In GSE152048 BC2, the malignant-cell L-M correlation was 0.378, compared with 0.097 in myeloid cells (P = 2.43e-11 by Fisher z test). In GSE152048 BC3, the corresponding values were 0.279 and 0.084 (P < 1e-300). In GSE162454 OS_4, malignant cells showed r = 0.566 versus r = 0.231 in myeloid cells (P < 1e-300). In GSE162454, the malignant correlation was also stronger than in fibroblasts, endothelial cells, and T/NK cells. In GSE318840, malignant cells showed positive L-M coupling (r = 0.185 and 0.284 in treated and recurrent samples, respectively), but the contrast with endothelial or stromal compartments was not significant. Together, these results support malignant-cell enrichment of L-M coupling relative to myeloid cells, while indicating that the coupling is not malignant-cell exclusive.

### L/M-high malignant states co-activate specific bridge axes

We next asked whether the coupling was concentrated in a specific malignant-cell state. Within malignant/osteoblastic cells, we defined L-high and M-high states using the upper quartile and compared them with the lower quartile. Three bridge axes were consistently elevated across all five samples: HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1.

For HK-PRKN, the Cliff's delta for L-high versus L-low malignant cells was 0.740 in GSE152048 BC2, 0.588 in GSE152048 BC3, 0.713 in GSE162454 OS_4, 0.313 in GSE318840 Treated1, and 0.417 in GSE318840 Recurrent1. SIRT1-ATG and HDAC6-SQSTM1 showed the same direction in all five samples, with the strongest effects in GSE162454 OS_4. HIF1A-BNIP3 was higher in L-high malignant cells across all five samples, but its M-high pattern was inconsistent.

We also compared malignant cells with myeloid cells. L and M scores were higher in malignant cells in all three datasets with adequate myeloid representation. In contrast, the individual bridge axes were context-dependent: HK-PRKN was higher in malignant cells in GSE152048 but higher in myeloid cells in GSE162454; HDAC6-SQSTM1 was higher in malignant cells in GSE152048 BC2 but higher in myeloid cells in GSE162454. The reproducible unit was therefore not "malignant cells" in general, but the L/M-high malignant-cell state.

### Spatial transcriptomics supports L/M-bridge-axis co-localization

To test whether the malignant-cell state was spatially organized, we analyzed two Visium samples from GSE299025. L and M scores showed positive spatial autocorrelation in both patients (L Moran's I = 0.353 and 0.221; M Moran's I = 0.369 and 0.347). Hypoxia and osteoblastic programs were also spatially structured.

Spot-level correlations were positive and reproducible. In PatientA and PatientB, respectively, L-M correlations were 0.603 and 0.441; L-HK-PRKN correlations were 0.485 and 0.425; L-HDAC6-SQSTM1 correlations were 0.376 and 0.328; and L-SIRT1-ATG correlations were 0.417 and 0.261. M scores showed similarly positive correlations with all three axes.

Neighborhood analysis showed that L/M-high spots were enriched for neighboring M2/TAM-high spots in both patients (observed neighbor fraction approximately 0.29 versus permutation mean 0.25; empirical P = 0.001). PatientB also showed significant enrichment of L/M-high spots near myeloid-high spots. These findings support a spatially structured coupling model in which L/M-high malignant regions are adjacent to immunosuppressive myeloid niches.

### Bridge-axis-informed drug prioritization

The bridge axes identified in single-cell and spatial analyses were mapped to candidate pharmacological strategies. HDAC6-SQSTM1 was prioritized for selective HDAC6 inhibitors such as ricolinostat and tubastatin A, because HDAC6 was a central shared network node and its axis was reproducible in spatial and single-cell analyses. HK-PRKN was prioritized for glycolytic HK2 inhibition (2-deoxy-D-glucose, lonidamine) and mitochondrial quality-control activators such as urolithin A. SIRT1-ATG was retained at moderate priority because SIRT1 modulation is context-dependent and indirect. These drug candidates are hypothesis-generating and require experimental validation; no causality is claimed from transcriptomic or spatial association.

## Discussion

This study reframes lactylation-mitophagy biology in osteosarcoma. Instead of reporting another lactylation-related prognostic signature, we tested whether the two programs are globally coupled and found that they are not reproducibly coupled in bulk tissue. The negative bulk result is not a failure of the analysis; it identifies an important boundary. The biologically relevant signal emerges when the analysis is resolved by cell type and spatial location.

The single-cell data show that L-M coupling is stronger in malignant/osteoblastic cells than in myeloid cells in datasets with sufficient myeloid representation. However, the coupling is not malignant-cell exclusive. Endothelial, fibroblast, and chondrocyte compartments can also show positive correlations, which prevents a simple "tumor-cell-only" interpretation. Instead, the data support a L/M-high malignant state in which specific bridge axes are co-activated. HK-PRKN, SIRT1-ATG, and HDAC6-SQSTM1 were consistently elevated in L-high and M-high malignant cells across five samples from three datasets.

The spatial results strengthen this conclusion. L and M programs were spatially autocorrelated, and their spot-level signals correlated with the three bridge axes in both Visium samples. L/M-high regions were also surrounded by M2/TAM-high spots, suggesting a relationship between the malignant metabolic state and an immunosuppressive myeloid niche. These findings provide a mechanistic hypothesis that links glycolysis-derived lactate, mitochondrial quality control, and the immune microenvironment, but they remain observational.

The study has limitations. Bulk associations for the lactylation program were nominal and did not survive conservative multiple-testing correction across all tested modules. The single-cell analysis used five representative samples rather than every available sample, and the datasets differ in platform, treatment status, and cell composition. Cell-type labels were marker-based, and spatial spots contain mixtures of cells. The spatial neighborhood enrichment is consistent but based on two patients. Drug prioritization was knowledge-based and did not use a completed LINCS/CMap connectivity analysis. Finally, the study identifies association and co-localization rather than causality.

These limitations define clear next steps. Full-sample single-cell integration, orthogonal protein-lactylation measurements, targeted perturbation of HK2, HDAC6, or SIRT1, and functional mitophagy assays would be required to establish mechanism. For now, the study provides a reproducible data-driven framework and a cell-state-specific hypothesis that is more precise than a bulk lactylation signature.

## Methods

### Bulk datasets and preprocessing

TARGET-OS open STAR-Counts files were downloaded from the GDC. Gene expression matrices were linked to clinical metadata at the patient level. The primary endpoint was a composite metastasis or relapse/progression event. GSE21257, GSE39055, GSE33382, and GSE16091 were processed from GEO series matrices. GSE42352 was excluded from independent validation because it is a SuperSeries containing GSE33382. RNA-seq and microarray cohorts were processed separately.

### Gene programs and scoring

A 28-gene lactylation-associated program was curated from writers, erasers, readers, lactate production/transport genes, and regulators. Mitophagy genes were derived from GO:0000423, with an extended sensitivity set from GO:0000423 plus KEGG hsa04137. Bulk and single-cell module scores were computed using rank-based single-sample enrichment; scores were standardized within cohort. A multiplicative LMC score was calculated as z(L) × z(M). The primary endpoint was locked before association testing.

### Bulk association analysis

Logistic regression was used to test associations between standardized scores and the locked endpoint. Sex- and age-adjusted models were used as sensitivity analyses. Effect sizes are reported as odds ratios per standard deviation with 95% confidence intervals. Nominal and FDR-adjusted P values are reported separately. The bulk differential expression analysis used a memory-safe linear model on log2-CPM and is treated as exploratory; a DESeq2 or edgeR analysis should replace it before final submission.

### Single-cell datasets and cell-type annotation

GSE152048, GSE162454, and GSE318840 were processed as 10x matrices. Samples were processed one at a time to remain within a 16 GB memory limit. Cells were filtered by minimum genes, normalized to 10,000 counts, and log-transformed. Major cell types were annotated using marker programs for malignant/osteoblastic, osteoprogenitor/MSC, chondrocyte, myeloid, T/NK, B/plasma, endothelial, and fibroblast compartments. KMeans clustering on principal components was used for malignant and myeloid substates.

### Single-cell state and bridge-axis analysis

Per-cell L, M, hypoxia, proliferation, EMT, osteoblastic, M1, M2/TAM, antigen-presentation, and stemness scores were computed from gene-wise standardized expression. Malignant and myeloid cells were analyzed separately. L-high and M-high cells were defined as the upper quartile within each sample and compared with the lower quartile. Cliff's delta and Mann-Whitney tests were used as descriptive measures. Cell-level P values are reported as exploratory because cells within a sample are not independent biological replicates.

### Spatial transcriptomics

GSE299025 PatientA and PatientB Visium matrices and tissue-position files were processed without images. Spots were normalized and log-transformed. L, M, bridge-axis, hypoxia, osteoblastic, myeloid, M2/TAM, M1, and antigen-presentation scores were calculated. Moran's I was computed using a six-nearest-neighbor spatial graph with Gaussian weights. Spot-level correlations used Spearman correlation. Neighborhood enrichment compared the fraction of high-target neighbors around high-focal spots with 1,000 label permutations.

### Drug prioritization

Drug candidates were assigned using target-level knowledge for HK2, PRKN/PINK1, SIRT1, ATG7, HDAC6, and SQSTM1. Development stage and rationale were recorded for each compound. These are hypothesis-generating candidates and were not tested experimentally.

## Data and code availability

All datasets are public. TARGET-OS data are available from the GDC. GEO datasets include GSE21257, GSE39055, GSE33382, GSE16091, GSE152048, GSE162454, GSE318840, and GSE299025. Analysis scripts and derived summary tables are stored in the project workspace and should be deposited in a public repository such as GitHub or Zenodo before submission.
