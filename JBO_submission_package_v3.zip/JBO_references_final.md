# References

[1] Emma C. Bull, Archana Singh, Amy M. Harden, Kirsty Soanes, Hala Habash, Lisa Toracchio, et al. Targeting metastasis in paediatric bone sarcomas. Mol Cancer. 2025;24(1):153. https://doi.org/10.1186/s12943-025-02365-z

[2] Sigbjørn Smeland, Stefan S. Bielack, Jeremy Whelan, Mark Bernstein, Pancras Hogendoorn, Mark D. Krailo, et al. Survival and prognosis with osteosarcoma: outcomes in more than 2000 patients in the EURAMOS-1 (European and American Osteosarcoma Study) cohort. European Journal of Cancer. 2019;109:36-50. https://doi.org/10.1016/j.ejca.2018.11.027

[3] Isabelle Corre, Franck Verrecchia, Vincent Crenn, Francoise Redini, and Valérie Trichet. The Osteosarcoma Microenvironment: A Complex but Targetable Ecosystem. Cells. 2020;9(4):976. https://doi.org/10.3390/cells9040976

[4] Chenglong Chen, Lu Xie, Tingting Ren, Yi Huang, Jie Xu, and Wei Guo. Immunotherapy for osteosarcoma: Fundamental mechanism, rationale, and recent breakthroughs. Cancer Letters. 2021;500:1-10. https://doi.org/10.1016/j.canlet.2020.12.024

[5] Paul S. Meltzer, and Lee J. Helman. New Horizons in the Treatment of Osteosarcoma. N Engl J Med. 2021;385(22):2066-2076. https://doi.org/10.1056/nejmra2103423

[6] Changwu Wu, Jun Tan, Hong Shen, Chao Deng, Christian Kleber, Georg Osterhoff, et al. Exploring the relationship between metabolism and immune microenvironment in osteosarcoma based on metabolic pathways. J Biomed Sci. 2024;31(1):4. https://doi.org/10.1186/s12929-024-00999-7

[7] Shengnan Yu, and Xudong Yao. Advances on immunotherapy for osteosarcoma. Mol Cancer. 2024;23(1):192. https://doi.org/10.1186/s12943-024-02105-9

[8] Shuangshuang Sun, Zhe Xu, Liying He, Yihui Shen, Yuqing Yan, Xubing Lv, et al. Metabolic regulation of cytoskeleton functions by HDAC6-catalyzed α-tubulin lactylation. Nat Commun. 2024;15(1):8377. https://doi.org/10.1038/s41467-024-52729-0

[9] Heyu Li, Chao Liu, Ran Li, Lili Zhou, Yu Ran, Qiqing Yang, et al. AARS1 and AARS2 sense l-lactate to regulate cGAS as global lysine lactyltransferases. Nature. 2024;634(8036):1229-1237. https://doi.org/10.1038/s41586-024-07992-y

[10] Enwei Wei, Donglei Ji, Yanjie Jia, Ze Sun, Chunfeng Gao, Caroline Zeng, et al. BRD9 recognizes lactate-induced H3K18 lactylation to drive oncogenic chromatin remodeling in hepatocellular carcinoma. Cell Death Differ. 2026;33(10):1946-1959. https://doi.org/10.1038/s41418-026-01698-6

[11] Runhua Du, Yanmei Gao, Cong Yan, Xuelian Ren, Shankang Qi, Guobin Liu, et al. Sirtuin 1/sirtuin 3 are robust lysine delactylases and sirtuin 1-mediated delactylation regulates glycolysis. iScience. 2024;27(10):110911. https://doi.org/10.1016/j.isci.2024.110911

[12] Carlos Moreno-Yruela, Di Zhang, Wei Wei, Michael Bæk, Wenchao Liu, Jinjun Gao, et al. Class I histone deacetylases (HDAC1–3) are histone lysine delactylases. Sci. Adv. 2022;8(3):eabi6696. https://doi.org/10.1126/sciadv.abi6696

[13] Guijin Zhai, Ziping Niu, Zixin Jiang, Fei Zhao, Siyu Wang, Chen Chen, et al. DPF2 reads histone lactylation to drive transcription and tumorigenesis. Proc. Natl. Acad. Sci. U.S.A. 2024;121(50):e2421496121. https://doi.org/10.1073/pnas.2421496121

[14] Hao Wang, Zhongxuan Wu, Rui Yang, Shenglin Xu, Shunjie Yao, Ziheng Wu, et al. DHX9 transcriptional upregulation and lactylation at K1024 fuels a glycolysis–histone lactylation loop in osteosarcoma. J Transl Med. 2026;24(1):1175. https://doi.org/10.1186/s12967-026-08493-4

[15] Zhaochen Tong, Yi Peng, Dong Wang, Lingpu Zhang, Sijie Wen, Zixin Li, et al. Bone‐Targeted Nanoparticles Enable Metabolic Reprogramming via cGAS Lactylation Suppression to Restore Chemosensitivity and Antitumor Immunity in Osteosarcoma. Advanced Materials. 2026;38(30):e73147. https://doi.org/10.1002/adma.73147

[16] Shidong Hu, Ling Wu, Jianhua Wang, and Fengsheng Dai. Lactylation-driven metabolic reprogramming promotes osteosarcoma malignancy via HDGF-mediated proliferation and immune modulation. Front. Immunol. 2026;17:1836254. https://doi.org/10.3389/fimmu.2026.1836254

[17] Chunfeng Fu, Jiaqin Wu, Shuwan Hou, Minfu Liu, Shunshun Wang, Qianqian Du, et al. Ginkgolide A Suppresses Osteosarcoma Proliferation and Activates the Apoptotic Pathway by Targeting the KAT2A-H3K18la Lactylation Axis. ACAMC. 2026;26. https://doi.org/10.2174/0118715206443791260209074742

[18] Zhou Xie, Xiao Qu, Jun Zhang, Yanran Huang, Zhao Runhan, Dagang Tang, et al. Integrative single-cell and bulk RNA-seq analysis identifies lactylation-related signature in osteosarcoma. Funct Integr Genomics. 2025;25(1):60. https://doi.org/10.1007/s10142-025-01559-4

[19] Xue Zhang, Mingyue Guan, Yuanyuan Wang, Chenglong Ding, Xingchen Yu, Jiale Shi, et al. PFKP promotes oncogenesis in osteosarcoma through PI3K/HIF-1α pathway-mediated H3K18la modification. Cellular Signalling. 2026;147:112733. https://doi.org/10.1016/j.cellsig.2026.112733

[20] Yan Huang, Tao Feng, Bo Yang, Qian Yu, Yisheng Wang, Liping Feng, et al. Single-cell multi-omics reveals NUF2 as a potential biomarker associated with the high-lactylation malignant state in osteosarcoma. Int J Biol Markers. 2026;41:03936155261465683. https://doi.org/10.1177/03936155261465683

[21] Natalie M. Niemi, and Jonathan R. Friedman. Coordinating BNIP3/NIX-mediated mitophagy in space and time. Biochemical Society Transactions. 2024;52(5):1969-1979. https://doi.org/10.1042/bst20221364

[22] Shuai Wang, Zhantao Deng, Yuanchen Ma, Jiewen Jin, Fangjie Qi, Shuxian Li, et al. The Role of Autophagy and Mitophagy in Bone Metabolic Disorders. Int. J. Biol. Sci. 2020;16(14):2675-2691. https://doi.org/10.7150/ijbs.46627

[23] Ming Chen, Ziheng Chen, Yueying Wang, Zheng Tan, Chongzhuo Zhu, Yanjun Li, et al. Mitophagy receptor FUNDC1 regulates mitochondrial dynamics and mitophagy. Autophagy. 2016;12(4):689-702. https://doi.org/10.1080/15548627.2016.1151580

[24] Chaojun Yan, Longlong Gong, Li Chen, Meng Xu, Hussein Abou-Hamdan, Mingliang Tang, et al. PHB2 (prohibitin 2) promotes PINK1-PRKN/Parkin-dependent mitophagy by the PARL-PGAM5-PINK1 axis. Autophagy. 2020;16(3):419-434. https://doi.org/10.1080/15548627.2019.1628520

[25] Konstantinos Palikaras, Eirini Lionaki, and Nektarios Tavernarakis. Mechanisms of mitophagy in cellular homeostasis, physiology and pathology. Nat Cell Biol. 2018;20(9):1013-1022. https://doi.org/10.1038/s41556-018-0176-2

[26] Sven Geisler, Kira M. Holmström, Diana Skujat, Fabienne C. Fiesel, Oliver C. Rothfuss, Philipp J. Kahle, et al. PINK1/Parkin-mediated mitophagy is dependent on VDAC1 and p62/SQSTM1. Nat Cell Biol. 2010;12(2):119-131. https://doi.org/10.1038/ncb2012

[27] Caterina Vianello, Veronica Cocetta, Daniela Catanzaro, Gerald W Dorn, Angelo De Milito, Flavio Rizzolio, et al. Cisplatin resistance can be curtailed by blunting Bnip3-mediated mitochondrial autophagy. Cell Death Dis. 2022;13(4):398. https://doi.org/10.1038/s41419-022-04741-9

[28] Lingyan Chen, Dejian Chen, Yiming Pan, Yimei Mo, Biyu Lai, Huiguang Chen, et al. Inhibition of mitochondrial OMA1 ameliorates osteosarcoma tumorigenesis. Cell Death Dis. 2024;15(11):786. https://doi.org/10.1038/s41419-024-07127-1

[29] Zhiwei Tao, Pingan Zou, Zhengxu Yang, Tao Xiong, Zhi Deng, and Qinchan Chen. Targeting TIMM23 to overcome osteosarcoma chemoresistance. Cell Death Dis. 2025;16(1):856. https://doi.org/10.1038/s41419-025-08106-w

[30] Lingyuan Zeng, Shuwei Li, Kaidong Wu, Xiaoyu Bai, and Long Zhang. Anti-tumor effects of Guggulsterone in osteosarcoma: Role of SIRT3-mediated PINK1-Parkin mitophagy activation. Phytomedicine. 2026;153:157860. https://doi.org/10.1016/j.phymed.2026.157860

[31] Xiuxin Han, Yiqin Li, Yongheng Liu, Feng Wang, Tingfang Li, Qingchen Zhang, et al. Integrated multi-omics reveals GABARAP-mediated mitophagy and pyruvate metabolism as key drivers of osteosarcoma progression. Front. Immunol. 2025;16:1680554. https://doi.org/10.3389/fimmu.2025.1680554

[32] Wei Shi, Lei Zhang, Liying Mei, Chengqi Zhang, Lei Liu, Nan Zhao, et al. Single-cell mitophagy patterns dictate intercellular crosstalk in the tumor microenvironment to promote osteosarcoma progression. Transl Cancer Res. 2026;15(6):499-499. https://doi.org/10.21037/tcr-2026-0735

[33] Weiji Weng, Zhenghui He, Zixuan Ma, Jialin Huang, Yuhan Han, Qiyuan Feng, et al. Tufm lactylation regulates neuronal apoptosis by modulating mitophagy in traumatic brain injury. Cell Death Differ. 2025;32(3):530-545. https://doi.org/10.1038/s41418-024-01408-0

[34] Jiaying Li, Xiaoxiao Shi, Jiatong Xu, Kaiyue Wang, Fangxing Hou, Xiaodong Luan, et al. Aldehyde Dehydrogenase 2 Lactylation Aggravates Mitochondrial Dysfunction by Disrupting PHB2 Mediated Mitophagy in Acute Kidney Injury. Advanced Science. 2025;12(8):2411943. https://doi.org/10.1002/advs.202411943

[35] Han‐jun Qin, Si‐ying He, Ting‐hui Xiao, Da‐mao Dai, Xin‐jia Hu, and Nan Jiang. Lactylation Reprogramming in the Bone Infection Microenvironment Identifies PGK1 K361 as a Potential Therapeutic Target for Osteogenic Dysfunction. Advanced Science. 2026;13(19):e23583. https://doi.org/10.1002/advs.202523583

[36] Xiaolin Deng, Yuan Huang, Jinge Zhang, Yuwen Chen, Feifan Jiang, Zicai Zhang, et al. Histone lactylation regulates PRKN-Mediated mitophagy to promote M2 Macrophage polarization in bladder cancer. International Immunopharmacology. 2025;148:114119. https://doi.org/10.1016/j.intimp.2025.114119

[37] Henghui Zhang, Dongqing Li, Mingqiang Su, Zaosong Zheng, Wei Chen, Haiyong Chen, et al. Lactate-driven H3K18 lactylation promotes cisplatin resistance in bladder cancer via HNRNPF-Parkin mediated mitophagy. Drug Resistance Updates. 2026;88:101435. https://doi.org/10.1016/j.drup.2026.101435

[38] Sihan Li, Qian Jiang, Quanji Wang, Xingbo Li, Zihan Wang, Linpeng Xu, et al. p300-mediated histone H3K18 lactylation promotes mitochondrial ROS accumulation via mitophagy inhibition to potentiate dopamine agonists efficacy in prolactinomas. Redox Biology. 2026;91:104077. https://doi.org/10.1016/j.redox.2026.104077

[39] Yuman He, Zhongzhong Ji, Yiming Gong, Liancheng Fan, Penghui Xu, Xinyu Chen, et al. Numb/Parkin-directed mitochondrial fitness governs cancer cell fate via metabolic regulation of histone lactylation. Cell Reports. 2023;42(2):112033. https://doi.org/10.1016/j.celrep.2023.112033

[40] Zhangjie Wang, Chaoyi Li, Ruiqiu Zhu, Minghao Duan, Zhenyu Kuang, Xin Li, et al. Targeting USP7 lactylation suppresses NSCLC tumorigenesis by promoting PINK1 ubiquitination and degradation. Autophagy. 2026:1-19. https://doi.org/10.1080/15548627.2026.2728617

[41] Yizhuo Wang, Xin Wang, Yang Liu, Jiayuan Xu, Jiyuan Zhu, Yufu Zheng, et al. A novel hypoxia- and lactate metabolism-related prognostic signature to characterize the immune landscape and predict immunotherapy response in osteosarcoma. Front. Immunol. 2024;15:1467052. https://doi.org/10.3389/fimmu.2024.1467052

[42] Yan Zhou, Dong Yang, Qingcheng Yang, Xiaobin Lv, Wentao Huang, Zhenhua Zhou, et al. Single-cell RNA landscape of intratumoral heterogeneity and immunosuppressive microenvironment in advanced osteosarcoma. Nat Commun. 2020;11(1):6322. https://doi.org/10.1038/s41467-020-20059-6

[43] Jihao Tu, Duo Wang, XiaoTian Zheng, and Bin Liu. Single-cell RNA datasets and bulk RNA datasets analysis demonstrated C1Q+ tumor-associated macrophage as a major and antitumor immune cell population in osteosarcoma. Front. Immunol. 2023;14:911368. https://doi.org/10.3389/fimmu.2023.911368

[44] Jiatong Li, Yang Bai, He Zhang, Ting Chen, and Guanning Shang. Single-cell RNA sequencing reveals the communications between tumor microenvironment components and tumor metastasis in osteosarcoma. Front. Immunol. 2024;15:1445555. https://doi.org/10.3389/fimmu.2024.1445555

[45] Yan Liao, Junkai Chen, Hao Yao, Ting Zheng, Jian Tu, Weidong Chen, et al. Single-cell profiling of SLC family transporters: uncovering the role of SLC7A1 in osteosarcoma. J Transl Med. 2025;23(1):103. https://doi.org/10.1186/s12967-025-06086-1

[46] Yujing Huang, Dongyan Cao, Manxue Zhang, Yue Yang, Gengming Niu, Lina Tang, et al. Exploring the impact of PDGFD in osteosarcoma metastasis through single-cell sequencing analysis. Cell Oncol. 2024;47(5):1715-1733. https://doi.org/10.1007/s13402-024-00949-3

[47] Yun Liu, Mingwei He, Haijun Tang, Tianyu Xie, Yunhua Lin, Shangyu Liu, et al. Single-cell and spatial transcriptomics reveal metastasis mechanism and microenvironment remodeling of lymph node in osteosarcoma. BMC Med. 2024;22(1):200. https://doi.org/10.1186/s12916-024-03319-w

[48] Aaron Michael Taylor, Jianting Sheng, Patrick Kwok Shing Ng, Jeffrey M. Harder, Parveen Kumar, Ju Young Ahn, et al. Immunosuppressive Tumor Microenvironment of Osteosarcoma. Cancers. 2025;17(13):2117. https://doi.org/10.3390/cancers17132117

[49] Consolato M. Sergi. Targeting the ‘garbage-bin’ to fight cancer: HDAC6 inhibitor WT161 has an anti-tumor effect on osteosarcoma and synergistically interacts with 5-FU. Bioscience Reports. 2021;41(8):BSR20210952. https://doi.org/10.1042/bsr20210952

[50] Hongchun Dai, Guangming Yi, Dong Jiang, Yanmei Min, and Zongwei Li. Circ_0000376 regulates miR-577/HK2/LDHA signaling pathway to promote the growth, invasion and glycolysis of osteosarcoma. J Orthop Surg Res. 2024;19(1):67. https://doi.org/10.1186/s13018-023-04520-y

[51] Zhong Lei, Huijie Duan, Tengfei Zhao, Yuxiang Zhang, Guoqi Li, Jiahong Meng, et al. PARK2 inhibits osteosarcoma cell growth through the JAK2/STAT3/VEGF signaling pathway. Cell Death Dis. 2018;9(3):375. https://doi.org/10.1038/s41419-018-0401-8

[52] Qiuming Zou, Xiaofeng Zhou, Jianqin Lai, Haixia Zhou, Jinxuan Su, Zhijing Zhang, et al. Targeting p62 by sulforaphane promotes autolysosomal degradation of SLC7A11, inducing ferroptosis for osteosarcoma treatment. Redox Biology. 2025;79:103460. https://doi.org/10.1016/j.redox.2024.103460

[53] Wanshun Liu, Lei Li, Xiaoming Bai, Mengxue Zhang, Wei Lv, Yongbin Ma, et al. Osteosarcoma Cell‐Derived Migrasomes Promote Macrophage M2 Polarization to Aggravate Osteosarcoma Proliferation and Metastasis. Advanced Science. 2025;12(17):2409870. https://doi.org/10.1002/advs.202409870

[54] Jinti Lin, Ankai Xu, Jiakang Jin, Man Zhang, Jianan Lou, Chao Qian, et al. MerTK-mediated efferocytosis promotes immune tolerance and tumor progression in osteosarcoma through enhancing M2 polarization and PD-L1 expression. OncoImmunology. 2022;11(1):2024941. https://doi.org/10.1080/2162402x.2021.2024941

[55] Jason Eigenbrood, Nathan Wong, Paul Mallory, Janice S. Pereira, Demond Williams, Douglass W. Morris-II, et al. Spatial Profiling Identifies Regionally Distinct Microenvironments and Targetable Immunosuppressive Mechanisms in Pediatric Osteosarcoma Pulmonary Metastases. Cancer Research. 2025;85(12):2320-2337. https://doi.org/10.1158/0008-5472.can-24-3723

