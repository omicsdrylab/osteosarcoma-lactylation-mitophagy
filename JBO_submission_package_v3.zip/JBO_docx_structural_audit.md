# DOCX structural audit

| File | Paragraphs | Words | Distinct citations | Reference entries | Author email | DESeq2 | Old log2-CPM phrase |
|---|---:|---:|---:|---:|---|---|---|
| JBO_manuscript_final.docx | 129 | 5183 | 55 | 55 | False | True | False |
| JBO_title_page_final.docx | 29 | 217 | 0 | 0 | True | False | False |
| JBO_highlights_final.docx | 6 | 40 | 0 | 0 | False | False | False |
| JBO_cover_letter_final.docx | 15 | 246 | 0 | 0 | True | True | False |

Visual PDF rendering was not possible because this Windows session has no active interactive login for Word COM and LibreOffice is not installed. The DOCX was structurally parsed successfully.
