# JBO Submission Checklist

- [x] Primary journal selected: Journal of Bone Oncology.
- [x] Article type selected: Original Research Article.
- [x] Structured abstract prepared: up to 300 words, four sections.
- [x] Keywords prepared: 6.
- [x] Highlights prepared: 5 bullets, all <=85 characters.
- [x] Graphical abstract prepared in portrait 531 x 1328 format; TIFF/PDF at 300 dpi.
- [x] Main text within 2,000-5,000 words.
- [x] Main figures limited to 6, below the 8 figure/table limit.
- [x] Figure callouts and Figure legends inserted in the manuscript.
- [x] Six separate figure files packaged as `Figure_1` to `Figure_6`.
- [x] 55 references selected and cited in order.
- [x] Author names, affiliations, email, and corresponding author inserted.
- [x] CRediT, funding, competing-interest, ethics, consent, and data statements inserted.
- [x] DESeq2 on raw TARGET-OS counts replaces the exploratory log2-CPM analysis; model includes sex and age.
- [x] Threshold sensitivity analysis for upper/lower 20th, 25th, 30th and 33rd percentiles completed.
- [x] Figure resolution, margin, and graphical-abstract orientation audited.
- [x] Author confirmed the padded Figure 5 copy and final Word pagination.
- [x] Author confirmed the funding and competing-interest statements.
- [x] Public code repository URL inserted: https://github.com/omicsdrylab/osteosarcoma-lactylation-mitophagy.


