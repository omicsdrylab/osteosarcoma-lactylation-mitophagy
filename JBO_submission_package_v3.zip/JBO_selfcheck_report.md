# JBO manuscript self-check report

Date: 2026-10-03
Scope: final Word files, 55-reference set, figure package, language and statistical claims.
Status: findings only. No manuscript edits were made in this pass.

## 1. Figures and JBO submission format

### What the guide actually requires

- Artwork must be supplied as separate files along with the manuscript.
- Each image must be cited in the manuscript text.
- Images must be numbered in the order they appear.
- Every image must have a caption with a brief title and description.
- Recommended formats include PDF/EPS for vector art and TIFF/JPG/PNG for photographs, with 300 dpi minimum for photographic images.

### Finding F1: figures are separate, but the package is incomplete

Severity: Major formatting gap.

- `JBO_manuscript_final.docx` contains no `Figure 1` to `Figure 6` callouts.
- The manuscript contains no figure legends section.
- Figure legends exist separately in `outputs/manuscript_v0/figure_legends.md` but were not inserted into the manuscript.
- `outputs/JBO_submission/figures_final/` currently contains only the Figure 5 safe copy.
- Figures 1-4 and 6 remain in `outputs/manuscript_v0/figures/` and are not part of the final submission package.

### Fix

- Insert `(Figure 1)` to `(Figure 6)` at the relevant Results sentences.
- Add a `Figure legends` section after the Discussion or before References.
- Copy all final figure files into `outputs/JBO_submission/figures_final/` with logical names such as `Figure_1`, `Figure_2`.
- Keep graphical abstract separate.

## 2. Citation identity and placement

### Verified

- 55/55 DOI records were previously checked against Crossref.
- Final reference numbering is 1-55 and follows first appearance in the manuscript.

### Finding C1: citations are attached to our own Results rather than to interpretation

Severity: Major.

Affected locations:

- Single-cell bridge-axis Results sentence: `[11,26,33,36-40,51-54]`.
- Spatial bridge-axis Results sentence: `[36-37,43,48-50]`.
- M2/TAM neighborhood Results sentence: `[43,48-50,55]`.
- Bulk negative-coupling Discussion sentence: `[18,20,41]`.

Why it matters: Results should report what this study found. Mechanism and drug references should support interpretation, not the raw observation. Attaching large citation blocks to Results can look artificial and can make a reviewer suspect that the citation was added to compensate for weak evidence.

Fix: delete citations from descriptive Results sentences and place the relevant references in Discussion interpretation sentences.

### Finding C2: reference 41 is not a lactylation-signature paper

Severity: Major.

`[41]` is a hypoxia- and lactate-metabolism prognostic signature. The manuscript uses it in the phrase "transcriptome-based lactylation signatures" together with genuine lactylation-signature papers.

Fix: remove `[41]` from that claim or replace it with a true lactylation-signature study. Keep `[41]` only for hypoxia/lactate context.

### Finding C3: the C1Q+ macrophage citation does not support an immunosuppressive M2/TAM claim

Severity: Major.

`[43]` reports C1Q+ tumor-associated macrophages as a major and antitumor population. It is not direct evidence for an immunosuppressive M2/TAM niche.

Fix: remove `[43]` from the M2/TAM-support sentence. Use the M2-polarization and efferocytosis studies, and keep the C1Q+ paper for macrophage heterogeneity only.

### Finding C4: named drugs are not supported by the cited references

Severity: Moderate to major.

- `[51]` is a WT161 HDAC6-inhibitor study, not ricolinostat or tubastatin A.
- `[52]` supports HK2/LDHA biology, not lonidamine, 2-DG, or urolithin A specifically.
- `[53]` is a PARK2 osteosarcoma study, not direct evidence for mitochondrial activators.
- `[54]` supports p62/SQSTM1 biology, not the whole drug-prioritization list.

Fix: either add compound-specific references or rewrite as target-level hypotheses and avoid claiming compound-level support.

### Finding C5: introduction citation blocks are too broad

Severity: Minor to moderate.

Paragraph 7 places four large blocks at the end of sentences. The references are mostly relevant, but the structure reads like citation stacking.

Fix: split the paragraph into smaller claims and distribute citations at the exact claim boundary. Use one or two review articles where a broad mechanism statement is intended.

## 3. Statistical and analytical self-check

### S1: single-cell cell-level P values are pseudoreplicated

Severity: Major.

The manuscript reports Fisher z P values down to `<1e-300` for correlations calculated across cells. Cells within one sample are not independent biological replicates.

Fix: report per-sample correlations and consistency as the primary evidence. If inferential testing is retained, use per-sample or pseudobulk summaries, or a mixed model with sample as a random effect. Move cell-level P values to an exploratory supplement or remove them.

### S2: spatial neighborhood permutation does not preserve spatial autocorrelation

Severity: Major.

The current label permutation compares high-focal spots with random labels. Because L, M and myeloid scores are spatially autocorrelated, a spatially unconstrained null can inflate significance.

Fix: use a spatially constrained null or clearly describe the permutation as descriptive. The safest manuscript wording is "enriched under this permutation model" rather than "significant."

### S3: biological sample selection is not fully described

Severity: Major.

Five single-cell samples and two Visium samples were selected. The selection rule is not stated.

Fix: state the inclusion rule before analyses and confirm that sample selection was not based on seeing the L/M result.

### S4: quartile thresholds and LMC product score need sensitivity checks

Severity: Moderate.

- L-high and M-high states use the upper quartile; results may depend on this threshold.
- `z(L) x z(M)` is a product score, not a formal interaction test.

Fix: report a threshold sensitivity analysis and use a regression interaction term for the coupling claim if possible.

### S5: DESeq2 model and nominal bulk associations

Severity: Moderate.

- DESeq2 adjusts for sex but not age.
- Bulk association P values are nominal and are not corrected across cohorts and modules.

Fix: justify or add age to the DESeq2 model. Keep the abstract and Discussion wording explicitly nominal.

### S6: reproducibility language is too strong for two spatial samples

Severity: Moderate.

The current wording can read as population-level reproducibility.

Fix: replace broad "reproducible" statements with "consistent in the two available spatial samples" or "observed across the analyzed datasets."

## 4. Language and AI-style self-check

### L1: the writing is not obviously AI-generated, but it has several AI-like moves

Severity: Minor to moderate.

Observed features:

- Defensive meta-commentary: "The negative bulk result is not a failure of the analysis; it identifies an important boundary."
- Framework-style claims: "This study reframes..."; "These findings define a cell-state-specific framework..."
- Repetition: `reproduc*` appears 11 times; `cell-state-specific` 4 times; `malignant/osteoblastic` 6 times; `rather than` 6 times.
- Results sentences mix observation with interpretation and citations.
- Long numeric sentences are occasionally overloaded.
- Generic significance language appears in places where a bounded statement would be stronger.

### L2: whether the existing skills can de-AI the text

Yes. The useful skills are:

- `nature-polishing`: structural reconstruction, sentence splitting, removal of repetitive or faux-elegant phrasing, claim/evidence boundary checks.
- `nature-shared` discussion and main-text discipline: moves interpretation out of Results and removes repetitive meta-commentary.
- `nature-statistics`: fixes inferential wording and statistical reporting.
- `nature-ref-verifier`: independent reference metadata checks.
- `nature-reviewer`: simulated reviewer-style stress test before submission.

The de-AI pass should happen after the content fixes, not before. Otherwise it would make unsupported claims sound better rather than more correct.

## Priority order for the next pass

1. Add figure callouts and figure legends; package all six figures.
2. Fix the four citation-support problems C1-C4.
3. Fix pseudoreplication and spatial-permutation wording.
4. Run the bounded language de-AI pass using `nature-polishing`.
5. Regenerate the final DOCX and rerun the package audit.

## Implementation status after this pass

- Figure 1-6 callouts inserted.
- Figure legends inserted.
- Six separate figure files packaged as `Figure_1` to `Figure_6`.
- The C1Q+ macrophage citation was removed from the M2/TAM support claim.
- The hypoxia/lactate-metabolism reference is now described accurately.
- Cell-level P values were removed from biological inference.
- Spatial label-permutation results are now explicitly descriptive.
- Threshold sensitivity at 20th, 25th, 30th and 33rd percentiles was completed and packaged as Supplementary Table S1.
- DESeq2 was refit with sex and age; FDR<0.05 is 431 and nominal P<0.05 is 4,033.
- Several defensive and framework-style phrases were removed from the abstract and discussion.
- Still pending: one visual check of the final Word pagination and Figure 5 safe copy, plus funding/conflict confirmation and the public code repository URL.

