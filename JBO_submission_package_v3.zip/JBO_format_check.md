# JBO Format Compliance Check

- Abstract words: 220
- Main text words excluding abstract, figure legends, references and declarations: 2256
- Highlight count: 5
- Highlight lengths: [64, 62, 68, 65, 66]
- Keywords: 6
- Main figures: 6
- Figure callouts: present for Figures 1-6
- Figure legends: present in the manuscript
- Separate figure files: packaged in `figures_final/Figure_1` to `Figure_6`
- References: 55
- Bulk DE: PyDESeq2 on raw TARGET-OS counts; design ~ condition + sex + age; 431 genes at FDR < 0.05; 4,033 genes at nominal P < 0.05
- Threshold sensitivity: Supplementary Table S1, 20th, 25th, 30th and 33rd percentiles
- Citation coverage: all 55 references cited at least once
- Graphical abstract: 531 x 1328 px portrait; TIFF/PDF at 300 dpi

- Code repository: https://github.com/omicsdrylab/osteosarcoma-lactylation-mitophagy

