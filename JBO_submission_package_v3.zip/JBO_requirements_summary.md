# Journal of Bone Oncology Submission Requirements Summary

## Journal choice
Primary target: **Journal of Bone Oncology (JBO)**.
Reason: it explicitly covers primary bone tumours, bone microenvironment, bone biomarkers, bone-targeted therapy, and osteo-oncology. Our study fits this scope better than the broader orthopaedic-surgery scope of JOSR. JOSR remains a fallback option.

## Article type requirements
- Article type: Original Research Article.
- Abstract: structured up to 300 words, preferably <=250 words to be safe. Sections: Background, Methods, Results, Conclusions.
- Keywords: 1-7.
- Highlights: required; 3-5 bullets; each <=85 characters including spaces.
- Graphical abstract: required; 531 x 1328 pixels (h x w) or proportionally more; readable at 5 x 13 cm; TIFF, EPS, PDF, or MS Office preferred.
- Main text: 2,000-5,000 words excluding abstract, figure legends, and references.
- Figures and tables: up to 8 combined main display items.
- References: 30-60, numbered in order of appearance, square-bracket citations, DOI where available.
- Editable source files: Word .doc/.docx or LaTeX .tex; Word should be single-column.
- Tables and equations must be editable text, not images.
- Figures must be separate files.
- Supplementary material must be cited in the manuscript and submitted simultaneously.
- Data statement required.
- CRediT author contribution statement required.
- Cover letter and title page with corresponding author email required.
- Open access journal; APC applies.

## Reference style
Use numbered references in square brackets in the order first cited. Include DOI when available. Example:
[1] J. van der Geer, T. Handgraaf, R.A. Lupton, The art of writing a scientific article, J. Sci. Commun. 163 (2020) 51-59. https://doi.org/...
